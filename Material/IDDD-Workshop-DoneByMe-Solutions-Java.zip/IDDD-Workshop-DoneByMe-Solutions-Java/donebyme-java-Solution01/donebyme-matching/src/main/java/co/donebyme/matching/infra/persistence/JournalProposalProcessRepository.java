package co.donebyme.matching.infra.persistence;

import co.donebyme.matching.infra.messaging.MatchingSaga;
import co.donebyme.matching.model.Id;
import co.vaughnvernon.mockroservices.journal.EntryStream;
import co.vaughnvernon.mockroservices.journal.EntryStreamReader;
import co.vaughnvernon.mockroservices.journal.Journal;
import co.vaughnvernon.mockroservices.journal.Repository;

public class JournalProposalProcessRepository extends Repository {
  
  private final Journal journal;
  private final EntryStreamReader reader;
  
  public MatchingSaga proposalProcessOf(final Id id) {
    final EntryStream stream =
        reader.streamFor(id.value);
    
    return new MatchingSaga(toSourceStream(stream.stream), stream.streamVersion);
  }

  public void save(final MatchingSaga proposalProcess) {
    journal.write(
        proposalProcess.id,
        proposalProcess.nextVersion(),
        toBatch(proposalProcess.applied()));
  }

  protected JournalProposalProcessRepository() {
    this.journal = Journal.open("donebyme-matching");
    this.reader = this.journal.streamReader();
  }

}
