package co.donebyme.matching.infra.messaging;

import java.util.Date;
import java.util.List;

import co.donebyme.matching.infra.persistence.Repositories;
import co.donebyme.matching.model.Id;
import co.donebyme.matching.model.proposal.Proposal;
import co.donebyme.pricing.command.AnalyzePricing;
import co.vaughnvernon.mockroservices.messagebus.Message;
import co.vaughnvernon.mockroservices.messagebus.MessageExchangeReader;
import co.vaughnvernon.mockroservices.messagebus.Subscriber;
import co.vaughnvernon.mockroservices.model.Command;
import co.vaughnvernon.mockroservices.model.DomainEvent;
import co.vaughnvernon.mockroservices.model.SourcedEntity;

public class MatchingSaga extends SourcedEntity<Command> implements Subscriber {
  private static final int ANALYZE_PRICING = 0;
  private static final int RECOMMEND_DOERS = 1;
  
  private boolean[] steps;
  public String id;
  private String[] keywords;
  private Date completedBy;
  private long price;
  
  MatchingSaga() {
    this.steps = new boolean[3];
  }
  
  @Override
  public void handle(Message message) {
    final MessageExchangeReader reader = MessageExchangeReader.from(message);

    switch (message.type) {
    
    // MATCHING...
    
    case "co.donebyme.matching.model.proposal.ProposalSubmitted":
      onProposalSubmitted(
              reader.stringValue("proposalId"),
              reader.stringArrayValue("keywords"),
              reader.dateValue("completedBy"),
              reader.longValue("price"));
      break;
      
    case "co.donebyme.matching.model.proposal.PricingVerified":
      onProposalPricingVerified(
              reader.stringValue("proposalId"),
              reader.stringArrayValue("clientId"),
              reader.longValue("price"));

      Repositories.proposalProcess().save(this);

      break;
      
    case "co.donebyme.matching.model.proposal.PricingDenied":
      onProposalPricingDenied(
              reader.stringValue("proposalId"),
              reader.stringValue("clientId"),
              reader.longValue("price"));

      repository.save(this);

      break;
      
      // PRICING...
      
    case "co.donebyme.pricing.model.analysis.PricingVerified":
      onPricingPricingVerified(
              reader.stringValue("originatorId"),
              reader.stringArrayValue("taxonomy"),
              reader.dateValue("dueDate"),
              reader.longValue("price"));

      repository.save(this);

      break;
    case "co.donebyme.pricing.model.analysis.PricingRejected":
      onPricingPricingRejected(
              reader.stringValue("originatorId"),
              reader.stringArrayValue("taxonomy"),
              reader.dateValue("dueDate"),
              reader.longValue("price"),
              reader.longValue("suggestedPrice"));

      repository.save(this);

      break;

      // PROFILES...
      
      // SCHEDULING...

    }
  }

  protected void when(AnalyzePricing command) {
    steps[ANALYZE_PRICING] = true;
  }

  protected void when(RecommendDoers command) {
    steps[RECOMMEND_DOERS] = true;
  }
  
  protected void when(ProposalInfoDefined event) {
    this.keywords = event.keywords;
    this.completedBy = event.completedBy;
    this.price = event.price;
  }

  private void onProposalPricingVerified(String proposalId, String[] taxonomy, long price) {
    if (!steps[RECOMMEND_DOERS]) {
      apply(new RecommendDoers(proposalId, keywords, price));
      Repositories.proposalProcess().save(this);
    }
  }
  
  private void onProposalSubmitted(String proposalId, String[] keywords, Date completedBy, long price) {
    if (!steps[ANALYZE_PRICING]) {
      apply(new AnalyzePricing(proposalId, keywords, completedBy, price), ProposalInfoDefined(id, keywords, completedBy, price));
      Repositories.proposalProcess().save(this);
    }
  }

  private void onPricingPricingVerified(String pricedItemId, String[] taxonomy, Date dueDate, long price) {
    Proposal proposal = Repositories.proposal().proposalOf(Id.fromExisting(pricedItemId));
    proposal.verifyPricing();
    Repositories.proposal().save(proposal);
  }

  private void onPricingPricingRejected(String pricedItemId, String[] taxonomy, Date dueDate, long price, long suggestedPrice) {
    Proposal proposal = Repositories.proposal().proposalOf(Id.fromExisting(pricedItemId));
    proposal.denyPricing(suggestedPrice);
    Repositories.proposal().save(proposal);
  }

  public MatchingSaga(final List<Command> stream, final long streamVersion) {
    super(stream, (int) streamVersion);
  }
}
