﻿using System.Collections.Generic;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Scheduling.Model
{
	public class AvailabiltyLocated : DomainEvent
	{
		public string ProposalId { get; private set; }
		public IEnumerable<Doer> Doers { get; }

        public AvailabiltyLocated(
	        Id proposalId,
	        IEnumerable<Doer> doers)
        {
	        ProposalId = proposalId.Value;
	        Doers = doers;
        }
	}
}
