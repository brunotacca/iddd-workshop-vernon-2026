﻿namespace DoneByMe.Scheduling.Model
{
    public class Doer
    {
		public Id Id { get; }
		public bool Preferred { get; }
  
		public static Doer NonPreferredFrom(string referencedId) => new Doer(Id.FromExisting(referencedId), false);

		public static Doer PreferredFrom(string referencedId) => new Doer(Id.FromExisting(referencedId), true);
		
		public static Doer From(string referencedId, bool isPreferred) => new Doer(Id.FromExisting(referencedId), isPreferred);

		public override int GetHashCode() => Id.GetHashCode() + (Preferred ? 1 : 0);

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Doer))
			{
				return false;
			}
    
			var otherDoer = (Doer) other;
    
			return Id.Equals(otherDoer.Id) && Preferred == otherDoer.Preferred;
		}

		public override string ToString() => $"Doer[Id={Id} Preferred={Preferred}]";

		private Doer(Id id, bool preferred)
		{
			Id = id;
			Preferred = preferred;
		}
	}
}
