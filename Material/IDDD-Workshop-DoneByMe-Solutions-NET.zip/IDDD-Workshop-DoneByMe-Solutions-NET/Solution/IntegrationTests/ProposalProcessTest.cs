using System;
using System.Collections.Generic;
using System.Threading;
using DoneByMe.Matching.Infra.Persistence;
using DoneByMe.Matching.Model;
using DoneByMe.Matching.Model.Proposals;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VaughnVernon.Mockroservices.MessageBuses;

namespace IntegrationTests
{
    [TestClass]
    public class ProposalProcessTest : ISubscriber
    {
        private bool received;
        
        [TestMethod]
        [Ignore("Failing because of concurrency issue while deserializing the stream")]
        public void TestThatAnalyzePricingIsEmitted()
        {
            DoneByMe.Matching.Infra.StartUp.Start();
            DoneByMe.Profile.Infra.StartUp.Start();
            
            MessageBus.Start("donebyme").OpenTopic("all").Subscribe(this);
            
            var proposal = Proposal.SubmitFor(Client(), Expectations());
            
            Repositories.ProposalRepository.Save(proposal);

            Pause();
            
            var existing = Repositories.ProposalRepository.ProposalOf(proposal.Id);

            Console.WriteLine($"#2 DOERS RECOMMENDED {(existing.Progress.DoersRecommended ? "YES" : "NO")}");

            Assert.IsNotNull(existing);

            Pause();

            Assert.IsTrue(received);

        }
        
        private Client Client()
        {
            return DoneByMe.Matching.Model.Client.From("12345", "Washington D.C.");
        }

        private Doer Doer()
        {
            return DoneByMe.Matching.Model.Doer.PreferredFrom("ABC");
        }
        
        private Expectations Expectations()
        {
            return
                DoneByMe.Matching.Model.Proposals.Expectations.Of(
                    Summary.Has("I need my windows washed by the best."),
                    Description.Has("When I say 'jump,' you ask 'how high?'"),
                    Keywords.Are("#windows", "#washing", "#indoor", "#outdoor", "#extra-tall"),
                    new DateTime(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() + 24 * 60 * 60 * 1000),
                    new HashSet<Step>(new []{ Step.Ordered(1, Description.Has("Step 1")) }), 
                    1995);
        }

        public void Handle(Message message)
        {
            switch (message.SimpleTypeName())
            {
                case "DoneByMe.Profile.Model.Doers.DoersRecommended":
                    received = true;
                    Console.WriteLine("Round Trip: DoersRecommended");
                    break;
            }
        }
        
        private void Pause() => Thread.Sleep(1000);
    }
}