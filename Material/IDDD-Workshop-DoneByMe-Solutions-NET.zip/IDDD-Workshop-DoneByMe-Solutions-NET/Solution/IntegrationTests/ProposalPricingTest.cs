﻿using System;
using System.Collections.Generic;
using System.Threading;
using DoneByMe.Matching.Infra.Persistence;
using DoneByMe.Matching.Model;
using DoneByMe.Matching.Model.Proposals;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VaughnVernon.Mockroservices;
using VaughnVernon.Mockroservices.MessageBuses;

namespace IntegrationTests
{
    [TestClass]
    public class ProposalSubmittedTest : ISubscriber
    {
        private bool received;

        [TestMethod]
        [Ignore("Failing because of concurrency issue while deserializing the stream")]
        public void TestProposalPricingVerified()
        {
            DoneByMe.Matching.Infra.StartUp.Start();
            DoneByMe.Pricing.Infra.StartUp.Start();

            MessageBus.Start("donebyme").OpenTopic("all").Subscribe(this);

            var proposal = Proposal.SubmitFor(GetClient(), GetExpectations());

            Repositories.ProposalRepository.Save(proposal);

            Pause();

            var existing = Repositories.ProposalRepository.ProposalOf(proposal.Id);

            Console.WriteLine($"#2 PRICING {(existing.Progress.WasPricingDenied ? "DENIED" : "VERIFIED")}");

            Assert.IsNotNull(existing);

            Pause();

            Assert.IsTrue(received);
        }

        public void Handle(Message message)
        {
            switch (message.SimpleTypeName())
            {
                case "DoneByMe.Pricing.Model.Analysis.PricingVerified":
                    received = true;
                    Console.WriteLine("Round Trip: PricingVerified");
                    break;
                case "DoneByMe.Pricing.Model.Analysis.PricingRejected":
                    received = true;
                    Console.WriteLine("Round Trip: PricingRejected");
                    break;
            }
        }

        private Client GetClient() => Client.From("12345", "Washington D.C.");

        private Expectations GetExpectations()
        {
            var steps = new HashSet<Step>();
            steps.Add(Step.Ordered(1, Description.Has("Step 1")));

            return
                Expectations.Of(
                    Summary.Has("A summary"),
                    Description.Has("A description"),
                    Keywords.Are("#windows", "#washing", "#indoor", "#outdoor", "#extra-tall"),
                    new DateTime(DateTime.Now.Ticks + (24 * 60 * 60 * 1000)),
                    steps,
                    1995);
        }

        private void Pause() => Thread.Sleep(1000);
    }
}
