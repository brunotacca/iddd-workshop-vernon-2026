﻿using System;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model;

// Adapter: Persistence for Person

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Infra.Persistence
{
    public class PersistencePersonRepository : PersonRepository
    {
        public Person PersonOf(Id id)
        {
            Console.WriteLine("Port Adapter: PersonRepository::PersonOf");
            // ...

            // mimic found person
            var found =
                    new Person(
                            id,
                            new Name("Jane", "Doe"),
                            new Contact("212-555-1212", "jane@doe.com"));

            return found;
        }

        public void Save(Person person)
        {
            Console.WriteLine("Port Adapter: PersonRepository::Save");
            // ...
        }
    }
}
