﻿using System;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model;

// Adapter: Persistence for Employee

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Infra.Persistence
{
    public class PersistenceEmployeeRepository : EmployeeRepository
    {
        public Employee EmployeeOf(Id id)
        {
            Console.WriteLine("Port Adapter: EmployeeRepository::EmployeeOf");
            // mimic found employee by employee id
            var found =
                    new Employee(
                            new Person(new Id("p123"), new Name("Jane", "Doe"), new Contact("212-555-1212", "jane@doe.com")),
                            DateTime.Now);

            return found;
        }

        public Employee EmployeeOfPerson(Id id)
        {
            Console.WriteLine("Port Adapter: EmployeeRepository::EmployeeOfPerson");
            // mimic found employee by person id
            var found =
                    new Employee(
                            new Person(new Id("p123"), new Name("Jane", "Doe"), new Contact("212-555-1212", "jane@doe.com")),
                            DateTime.Now);

            return found;
        }

        public void Save(Employee employee)
        {
            Console.WriteLine("Port Adapter: EmployeeRepository::Save");
            // ...
        }
    }
}
