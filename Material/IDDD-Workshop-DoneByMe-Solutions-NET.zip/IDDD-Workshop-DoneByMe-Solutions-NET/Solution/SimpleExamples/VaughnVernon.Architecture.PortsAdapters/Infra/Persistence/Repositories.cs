﻿using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model;

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Infra.Persistence
{
    public class Repositories
    {
        public static readonly EmployeeRepository EmployeeRepository =
            new PersistenceEmployeeRepository();

        public static readonly PersonRepository PersonRepository =
            new PersistencePersonRepository();
    }
}
