﻿using System;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Application;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model;

// Adapter: REST resource handler for Person

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Infra.Resources
{
   public class PersonResource
    {
        private readonly PersonApplicationService service;

        public PersonResource(PersonApplicationService service)
        {
            this.service = service;
        }

        // GET /assets/people/{personId}
        public Person GetPerson(string personId)
        {
            Console.WriteLine("Port Adapter: PersonResource::GetPerson");
            return service.PersonOf(personId);
        }

        // POST /assets/people
        public Person PostPerson(
                string givenName,
                string familyName,
                string mobilePhone,
                string emailAddress)
        {
            Console.WriteLine("Port Adapter: PersonResource::PostPerson");
            var id = Id.Unique().Value;
            service.RecordPerson(id, new Name(givenName, familyName), new Contact(mobilePhone, emailAddress));
            return service.PersonOf(id);
        }
    }
}
