﻿using System;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Application;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model;

// Adapter: REST resource handler for Employee

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Infra.Resources
{
    public class EmployeeResource
    {
        private readonly EmployeeApplicationService service;

        public EmployeeResource(EmployeeApplicationService service)
        {
            this.service = service;
        }

        // GET /assets/employees/{id}?usePersonId=bool
        public Employee GetEmployee(string id, bool usePersonId)
        {
            Console.WriteLine("Port Adapter: EmployeeResource::GetEmployee");
            if (usePersonId)
            {
                return service.EmployeeOfPerson(id);
            }
            return service.EmployeeOf(id);
        }

        // POST /assets/employees
        public Employee PostEmployee(string personId, DateTime dateHired)
        {
            Console.WriteLine("Port Adapter: EmployeeResource::PostEmployee");
            service.Hire(personId, dateHired);
            return service.EmployeeOfPerson(personId);
        }
    }
}
