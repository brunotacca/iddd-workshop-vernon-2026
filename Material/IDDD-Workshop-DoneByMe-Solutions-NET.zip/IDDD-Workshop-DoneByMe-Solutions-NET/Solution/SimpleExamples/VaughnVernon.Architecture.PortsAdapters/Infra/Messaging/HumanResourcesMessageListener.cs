﻿using System;
using VaughnVernon.Mockroservices.MessageBuses;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Application;

// Adapter: Message Listener for Person/Employee happenings

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Infra.Messaging
{
    public class HumanResourcesMessageListener
    {
        public void Receive(Message message)
        {
            Console.WriteLine("Port Adapter: HumanResourcesMessageListener::receive");
            if (message.Type.Equals("PersonHired"))
            {
                var personId = message.Id;
                Services.EmployeeApplicationService.Hire(personId, HireDateFrom(message.Payload));
            }
        }

        private DateTime HireDateFrom(string payload)
        {
            return DateTime.Now; // simulate reading date from payload
        }
    }
}
