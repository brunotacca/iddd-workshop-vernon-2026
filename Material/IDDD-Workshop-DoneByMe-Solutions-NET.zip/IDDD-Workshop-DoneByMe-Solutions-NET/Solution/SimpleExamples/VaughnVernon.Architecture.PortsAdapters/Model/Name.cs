﻿namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model
{
    public class Name
    {
        public string Given { get; private set; }
        public string Family { get; private set; }

        public Name(string given, string family)
        {
            Given = given;
            Family = family;
        }
    }
}
