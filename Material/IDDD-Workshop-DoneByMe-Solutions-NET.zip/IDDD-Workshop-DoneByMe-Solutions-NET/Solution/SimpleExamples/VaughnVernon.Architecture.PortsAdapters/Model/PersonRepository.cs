﻿namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model
{
    public interface PersonRepository
    {
        Person PersonOf(Id id);

        void Save(Person person);
    }
}
