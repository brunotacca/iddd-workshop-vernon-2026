﻿using System;

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model
{
    // Model: Employee Aggregate

    public class Employee
    {
        public DateTime DateHired { get; private set; }

        // Aggregate Rule #3: Reference By Id Only: private Id personId;
        public Person Person { get; private set; }

        public static Employee HireAsOf(Person person, DateTime dateHired)
        {
            Console.WriteLine("Model: Employee::HireAsOf");
            return new Employee(person, dateHired);
        }

        public Employee(Person person, DateTime dateHired)
        {
            Console.WriteLine("Model: Employee::ctor");
            Person = person;
            DateHired = dateHired;
        }
    }
}
