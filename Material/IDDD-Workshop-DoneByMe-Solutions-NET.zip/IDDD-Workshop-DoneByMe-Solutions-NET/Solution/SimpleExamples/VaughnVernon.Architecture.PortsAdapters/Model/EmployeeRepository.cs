﻿namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model
{
    public interface EmployeeRepository
    {
        Employee EmployeeOf(Id id);

        Employee EmployeeOfPerson(Id id);

        void Save(Employee employee);
    }
}
