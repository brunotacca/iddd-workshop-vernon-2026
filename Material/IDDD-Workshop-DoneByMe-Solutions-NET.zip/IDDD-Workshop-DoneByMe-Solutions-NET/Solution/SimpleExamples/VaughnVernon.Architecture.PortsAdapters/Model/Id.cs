﻿using System;

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model
{
    // Model: Id Value Object

    public class Id
    {
        public string Value { get; private set; }

        public static Id Unique()
        {
            return new Id(Guid.NewGuid().ToString());
        }

        public Id(string value)
        {
            Value = value;
        }
    }
}
