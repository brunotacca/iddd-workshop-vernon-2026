﻿namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model
{
    public class Contact
    {
        public string Mobile { get; private set; }
        public string Email { get; private set; }

        public Contact(string mobile, string email)
        {
            Mobile = mobile;
            Email = email;
        }
    }
}
