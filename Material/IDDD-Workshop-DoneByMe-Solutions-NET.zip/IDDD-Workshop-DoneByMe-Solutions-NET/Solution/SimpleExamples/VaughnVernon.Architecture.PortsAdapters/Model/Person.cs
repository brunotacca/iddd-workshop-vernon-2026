﻿using System;

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model
{
    public class Person
    {
        public Id Id;
        public Contact Contact;
        public Name Name;

        public Person(Id id, Name name, Contact contact)
        {
            Console.WriteLine("Model: Person::ctor");
            Id = id;
            Name = name;
            Contact = contact;
        }
    }
}
