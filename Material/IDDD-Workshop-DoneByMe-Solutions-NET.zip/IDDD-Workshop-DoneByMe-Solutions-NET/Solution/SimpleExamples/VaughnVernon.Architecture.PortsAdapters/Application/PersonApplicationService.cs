﻿using System;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model;

// Application Service for Person operations

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Application
{
    public class PersonApplicationService
    {
        private readonly PersonRepository personRepository;

        public PersonApplicationService(PersonRepository personRepository)
        {
            this.personRepository = personRepository;
        }

        public void RecordPerson(string id, Name name, Contact contact)
        {
            Console.WriteLine("Application: PersonApplicationService::RecordPerson");
            var person = new Person(new Id(id), name, contact);
            personRepository.Save(person);
        }

        public Person PersonOf(string id)
        {
            Console.WriteLine("Application: PersonApplicationService::PersonOf");
            return personRepository.PersonOf(new Id(id));
        }
    }
}
