﻿using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Infra.Persistence;

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Application
{
    public class Services
    {
        public static EmployeeApplicationService EmployeeApplicationService =
            new EmployeeApplicationService(Repositories.EmployeeRepository, Repositories.PersonRepository);

        public static readonly PersonApplicationService PersonApplicationService =
            new PersonApplicationService(Repositories.PersonRepository);
    }
}
