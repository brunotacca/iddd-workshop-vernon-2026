﻿using System;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Model;

// Application Service for Employee operations

namespace VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Application
{
    public class EmployeeApplicationService
    {
        private readonly EmployeeRepository employeeRepository;
        private readonly PersonRepository personRepository;

        public EmployeeApplicationService(EmployeeRepository employeeRepository, PersonRepository personRepository)
        {
            this.employeeRepository = employeeRepository;
            this.personRepository = personRepository;
        }

        public Employee EmployeeOf(string employeeId)
        {
            Console.WriteLine("Application: EmployeeApplicationService::EmployeeOf");
            return employeeRepository.EmployeeOf(new Id(employeeId));
        }

        public Employee EmployeeOfPerson(string personId)
        {
            Console.WriteLine("Application: EmployeeApplicationService::EmployeeOfPerson");
            return employeeRepository.EmployeeOfPerson(new Id(personId));
        }

        public void Hire(string personId, DateTime dateHired)
        {
            Console.WriteLine("Application: EmployeeApplicationService::Hire");
            var person = personRepository.PersonOf(new Id(personId));
            var employee = Employee.HireAsOf(person, dateHired);
            employeeRepository.Save(employee);
        }
    }
}
