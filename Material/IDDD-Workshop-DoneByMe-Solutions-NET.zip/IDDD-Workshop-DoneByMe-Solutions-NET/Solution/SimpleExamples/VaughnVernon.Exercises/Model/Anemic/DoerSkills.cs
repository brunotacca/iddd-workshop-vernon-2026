﻿using System.Collections.Generic;

namespace VaughnVernon.VaughnVernon.Exercises.Model.Anemic
{
    public class DoerSkills
    {
        private readonly IDictionary<string, Skill> dict = new Dictionary<string, Skill>();

        public void AddSkill(Skill skill)
        {
            dict.Add(skill.Name, skill);
        }

        public Skill GetSkill(string skillName)
        {
            if (!dict.ContainsKey(skillName))
            {
                return null;
            }
            return dict[skillName];
        }

        public void DeleteSkill(string skillName)
        {
            dict.Remove(skillName);
        }

        public class Skill
        {
            public string Name { get; set; }
            public long Price { get; set; }
        }
    }
}
