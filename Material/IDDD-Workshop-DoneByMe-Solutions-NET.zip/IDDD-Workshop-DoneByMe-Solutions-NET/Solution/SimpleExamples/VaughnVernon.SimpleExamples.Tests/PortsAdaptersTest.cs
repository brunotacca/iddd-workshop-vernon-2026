﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Application;
using VaughnVernon.VaughnVernon.Architecture.PortsAdapters.Infra.Resources;

namespace VaughnVernon.VaughnVernon.SimpleExamples.Tests
{
    [TestClass]
    public class PortsAdaptersTest
    {
        [TestMethod]
        public void TestThatLayersExecute()
        {
            Console.WriteLine("Executing Layers...");

            Console.WriteLine("BOOTSTRAP");
            var personResource = new PersonResource(Services.PersonApplicationService);
            personResource.PostPerson("Jane", "Doe", "212-555-1212", "jane@doe.com");
            Console.WriteLine("BOOTSTRAP");
            personResource.GetPerson("p123");

            Console.WriteLine("BOOTSTRAP");
            var employeeResource = new EmployeeResource(Services.EmployeeApplicationService);
            employeeResource.PostEmployee("p123", DateTime.Now);
            Console.WriteLine("BOOTSTRAP");
            employeeResource.GetEmployee("p123", true);
            Console.WriteLine("BOOTSTRAP");
            employeeResource.GetEmployee("e123", false);
        }
    }
}
