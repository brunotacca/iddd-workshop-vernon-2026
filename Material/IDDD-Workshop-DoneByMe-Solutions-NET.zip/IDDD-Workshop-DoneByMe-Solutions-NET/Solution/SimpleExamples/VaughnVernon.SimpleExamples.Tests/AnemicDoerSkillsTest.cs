﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using VaughnVernon.VaughnVernon.Exercises.Model.Anemic;
using static VaughnVernon.VaughnVernon.Exercises.Model.Anemic.DoerSkills;

namespace VaughnVernon.VaughnVernon.SimpleExamples.Tests
{
    [TestClass]
    public class AnemicDoerSkillsTest
    {
        [TestMethod]
        public void TestThatAnemicModelSucks()
        {
            var doerSkills = new DoerSkills();
            var skill = new Skill();
            skill.Name = "window-washing";
            skill.Price = 10000;
            doerSkills.AddSkill(skill);
            Assert.IsNotNull(doerSkills.GetSkill("window-washing"));
            doerSkills.DeleteSkill("window-washing");
            Assert.IsNull(doerSkills.GetSkill("window-washing"));
        }
    }
}
