﻿using System.Collections.Generic;
using System.Linq;

namespace DoneByMe.Profile.Model.DoerSkills
{
    public sealed class Skills
    {
        private readonly HashSet<Skill> skills;

        public static Skills StartingWith(params Skill[] skills) => new Skills(skills);

        public Skills Declare(Skill skill)
        {
            var newSkills = new HashSet<Skill>(skills);
            newSkills.Add(skill);
            return new Skills(newSkills);
        }

        public bool Declares(Skill skill) => skills.Contains(skill);

        public Rank RankFor(SkillClassification classification)
        {
            return skills
                .Where(s => s.Classification.Equals(classification))
                .Select(s => s.Rank())
                .DefaultIfEmpty(Rank.Of(0))
                .First();
        }

        private Skills(HashSet<Skill> skills) => this.skills = skills;

        private Skills(params Skill[] skills) => this.skills = new HashSet<Skill>(skills);
    }
}
