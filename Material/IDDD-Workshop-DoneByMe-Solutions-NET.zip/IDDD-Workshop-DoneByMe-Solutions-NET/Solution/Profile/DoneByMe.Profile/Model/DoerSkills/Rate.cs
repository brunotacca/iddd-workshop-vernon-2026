﻿namespace DoneByMe.Profile.Model.DoerSkills
{
    public class Rate
    {
        public enum RateType { Hourly, Flat };

        public Money Amount { get; }
        public RateType Type { get; }

        public static Rate FlatRateOf(long amount) => new Rate(RateType.Flat, Money.Of(amount));

        public static Rate FlatRateOf(Money money) => new Rate(RateType.Flat, money);

        public static Rate HourlyRateOf(long amount) => new Rate(RateType.Hourly, Money.Of(amount));

        public static Rate HourlyRateOf(Money money) => new Rate(RateType.Hourly, money);

        public override bool Equals(object other)
        {
            if (other == null || other.GetType() != GetType())
            {
                return false;
            }
            
            var otherRate = (Rate)other;
            return Type == otherRate.Type && Amount.Equals(otherRate.Amount);
        }

        public override int GetHashCode() => 31 * Type.GetHashCode() * Amount.GetHashCode();

        public override string ToString() => $"Rate[type={Type}, money={Amount}]";

        public int CompareTo(Rate other)
        {
            var typeCompare = Type.CompareTo(other.Type);
            if (typeCompare != 0) return typeCompare;
            if (Amount.Equals(other.Amount)) return (int)(Amount.Value - other.Amount.Value);
            return 0;
        }

        private Rate(RateType type, Money amount)
        {
            Type = type;
            Amount = amount;
        }
    }
}
