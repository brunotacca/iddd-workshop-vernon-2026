﻿using System.Collections.Generic;
using System.Linq;

namespace DoneByMe.Profile.Model.DoerSkills
{
    public class Keyword
    {
        public string Value { get; }

        public static Keyword Is(string value) => new Keyword(value);
        
        public static IEnumerable<Keyword> From(string[] keywords) => keywords.Select(Is);

        public override bool Equals(object other)
        {
            if (other == null || other.GetType() != GetType())
            {
                return false;
            }
            return Value.Equals(((Keyword) other).Value);
        }

        public override int GetHashCode() => 31 * Value.GetHashCode();

        private Keyword(string value) => Value = value;
    }
}
