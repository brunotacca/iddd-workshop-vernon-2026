﻿using System.Linq;

namespace DoneByMe.Profile.Model.DoerSkills
{
    public class Skill
    {
        public SkillClassification Classification { get; private set; }
        public Qualifications Qualifications { get; private set; }
        public Rate Rate { get; private set; }

        public static Skill Of(SkillClassification classification, Qualifications qualifications, Rate rate) 
            => new Skill(classification, qualifications, rate);
        
        public Rank Rank() => DoerSkills.Rank.Of(Qualifications.AsEnumerable().Select(MapScore).Sum());

        public int CompareTo(Skill other)
        {
            if (!Classification.Equals(other.Classification)) return -1;

            if (!Qualifications.Equals(other.Qualifications)) return -1;

            return Rate.CompareTo(other.Rate);
        }

        private Skill(SkillClassification classification, Qualifications qualifications, Rate rate)
        {
            Classification = classification;
            Qualifications = qualifications;
            Rate = rate;
        }
        
        private double MapScore(Qualification qualification)
        {
            switch (qualification)
            {
                case Qualification.Bonded:
                    return 0.50;
                case Qualification.Certified:
                    return 0.60;
                case Qualification.Expert:
                    return 0.80;
                case Qualification.Licensed:
                    return 0.85;
                case Qualification.Specialty:
                    return 0.45;
                case Qualification.Years:
                    return 0.75;
                case Qualification.Other:
                    return 0.20;
            }

            return 0;
        }
    }
}
