﻿using System.Collections.Generic;
using System.Linq;

namespace DoneByMe.Profile.Model.DoerSkills
{
    public class Qualifications
    {
        private readonly HashSet<Qualification> all;

        public static Qualifications Of(params Qualification[] qualifications) => new Qualifications(qualifications);

        public bool Has(Qualification qualification) => all.Contains(qualification);
        
        public IEnumerable<Qualification> AsEnumerable() => all.ToList();

        public Qualifications With(Qualification qualification)
        {
            if (Has(qualification))
            {
                return this;
            }
            
            var more = new HashSet<Qualification>(all);
            more.Add(qualification);
            return new Qualifications(more);
        }

        public override bool Equals(object other)
        {
            if (other == null || other.GetType() != GetType())
            {
                return false;
            }
            var otherAll = ((Qualifications)other).all;
            if (all.Count == otherAll.Count)
            {
                foreach (var qualification in all)
                {
                    if (!otherAll.Contains(qualification))
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return 31 * all.GetHashCode();
        }

        private Qualifications(params Qualification[] qualifications) => all = new HashSet<Qualification>(qualifications);

        private Qualifications(HashSet<Qualification> all) => this.all = all;
    }
}
