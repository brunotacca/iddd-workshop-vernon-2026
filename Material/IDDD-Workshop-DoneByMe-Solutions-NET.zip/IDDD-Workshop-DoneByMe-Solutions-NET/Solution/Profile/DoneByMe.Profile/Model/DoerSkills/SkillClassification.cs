﻿using System.Collections.Immutable;

namespace DoneByMe.Profile.Model.DoerSkills
{
    public class SkillClassification
    {
        public ImmutableList<Keyword> OrderedKeywords { get; }

        public static SkillClassification From(params Keyword[] orderedKeywords) => new SkillClassification(orderedKeywords);

        public override bool Equals(object other)
        {
            if (other == null || other.GetType() != GetType())
            {
              return false;
            }

            var orderedKeywords = ((SkillClassification)other).OrderedKeywords;

            if (OrderedKeywords.Count == orderedKeywords.Count)
            {
                for (var idx = 0; idx < OrderedKeywords.Count; ++idx)
                {
                    if (!OrderedKeywords[idx].Equals(orderedKeywords[idx]))
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        public override int GetHashCode() => 31 * OrderedKeywords.GetHashCode();

        private SkillClassification(params Keyword[] orderedKeywords) => OrderedKeywords = orderedKeywords.ToImmutableList();
    }
}
