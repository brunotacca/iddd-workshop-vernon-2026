﻿namespace DoneByMe.Profile.Model.DoerSkills
{
    public enum Qualification
    {
        Licensed, Certified, Bonded, Years, Specialty, Expert, Other
    }
}
