﻿namespace DoneByMe.Profile.Model.DoerSkills
{
    public class Rank
    {
        private Rank(double total) => Total = total;

        public double Total { get; }

        public Ranking.Ranking.Preferredness Preferredness { get; }

        public static Rank Of(double total) => new Rank(total);

        public static Ranking.Ranking.Preferredness PreferrednessOf(double total) 
            => total > 2.0 ? Ranking.Ranking.Preferredness.Preferred : Ranking.Ranking.Preferredness.NonPreferred;
    }
}