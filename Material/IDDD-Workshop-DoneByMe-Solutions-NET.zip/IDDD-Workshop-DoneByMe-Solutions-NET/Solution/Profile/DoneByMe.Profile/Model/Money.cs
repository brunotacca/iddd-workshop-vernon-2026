﻿using System;

namespace DoneByMe.Profile.Model
{
    public class Money
    {
        public readonly long Value;

        public static Money Of(Money money) => new Money(money);

        public static Money Of(long value) => new Money(value);

        public static Money None() => new Money();

        public Money(Money money) => Value = money.Value;

        public Money(long amount) => Value = amount;

        public Money() => Value = 0;

        public Money Add(Money money) => new Money(Value + money.Value);

        public Money DivideBy(int factor) => new Money(Value / factor);

        public Money MultiplyBy(int factor) => new Money(Value * factor);

        public Money Subtract(Money money) => new Money(Value - money.Value);

        public string ScaledBy(int scale)
        {
            var textValue = Value.ToString();
            if (textValue.Length < scale)
            {
                throw new InvalidOperationException($"Value cannot be scaled by {scale}");
            }

            if (textValue.Length == scale)
            {
                return $"0.{textValue}";
            }
            var position = textValue.Length - scale;
            var left = textValue.Substring(0, position);
            var right = textValue.Substring(position);
            return $"{left}.{right}";
        }

        public override bool Equals(object other)
        {
            if (other == null || other.GetType() != GetType())
            {
                return false;
            }
            return Value == ((Money)other).Value;
        }

        public override int GetHashCode() => (int)(31 * Value + Value);

        public override string ToString() => $"Money[Value={Value}]";
    }
}
