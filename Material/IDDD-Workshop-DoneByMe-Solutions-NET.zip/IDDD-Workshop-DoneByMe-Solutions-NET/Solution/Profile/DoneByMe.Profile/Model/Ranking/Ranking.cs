﻿using System.Collections.Generic;
using DoneByMe.Profile.Model.DoerSkills;

namespace DoneByMe.Profile.Model.Ranking
{
    public class Ranking
    {
        public enum Preferredness { Preferred, NonPreferred };

        public Locality locality;
        
        public IEnumerable<DoerRank> doerRanks;

        public SkillClassification classification;
        
        public static Ranking From(
            IEnumerable<DoerRank> doerRanks,
            SkillClassification classification,
            Locality locality) => new Ranking(doerRanks, classification, locality);
        
        private Ranking(
            IEnumerable<DoerRank> doerRanks,
            SkillClassification classification,
            Locality locality)
        {
            this.doerRanks = doerRanks;
            this.classification = classification;
            this.locality = locality;
        }
    }
}
