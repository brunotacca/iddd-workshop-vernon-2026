﻿using System.Collections.Generic;
using DoneByMe.Profile.Model.Doers;
using DoneByMe.Profile.Model.DoerSkills;

namespace DoneByMe.Profile.Model.Ranking
{
    public class RankingCalculator
    {
        public Ranking RankAmong(SkillClassification classification, Locality locality, IEnumerable<Doer> doers)
        {
            var doerRanks = new SortedSet<DoerRank>();

            foreach (var doer in doers)
            {
                doerRanks.Add(DoerRank.Combines(doer, doer.RankFor(classification)));
            }

            return Ranking.From(doerRanks, classification, locality);
        }
    }
}
