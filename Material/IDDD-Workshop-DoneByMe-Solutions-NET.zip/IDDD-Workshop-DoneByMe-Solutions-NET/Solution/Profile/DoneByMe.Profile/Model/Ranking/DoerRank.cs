using System;
using DoneByMe.Profile.Model.Doers;
using DoneByMe.Profile.Model.DoerSkills;

namespace DoneByMe.Profile.Model.Ranking
{
    public class DoerRank : IComparable<DoerRank>
    {
        public Doer Doer { get; }
        public Rank Rank { get; }

        public static DoerRank Combines(Doer doer, Rank rank) => new DoerRank(doer, rank);

        private DoerRank(Doer doer, Rank rank)
        {
            Doer = doer;
            Rank = rank;
        }

        public int CompareTo(DoerRank other) => - Rank.Total.CompareTo(other.Rank.Total);
    }
}    