﻿namespace DoneByMe.Profile.Model
{
    public class Locality
    {
        public string Address { get; }

        public Locality(string locality)
        {
            Address = locality;
        }
        
        public static Locality From(string locality) => new Locality(locality);
    }
}
