namespace DoneByMe.Profile.Model.Doers
{
    public class RecommendedDoer
    {
        public string Id { get; }
        public bool Preferred { get; }

        public RecommendedDoer(string id, bool preferred)
        {
            Id = id;
            Preferred = preferred;
        }
    }
}