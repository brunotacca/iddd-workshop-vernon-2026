using System.Collections.Generic;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Profile.Model.Doers
{
    public class DoersRecommended : DomainEvent
    {
        public string ProposalId { get; }
        public IEnumerable<RecommendedDoer> Doers { get; }
        public string Locality { get; }

        public DoersRecommended(string proposalId, IEnumerable<RecommendedDoer> doers, string locality)
        {
            ProposalId = proposalId;
            Doers = doers;
            Locality = locality;
        }
    }
}