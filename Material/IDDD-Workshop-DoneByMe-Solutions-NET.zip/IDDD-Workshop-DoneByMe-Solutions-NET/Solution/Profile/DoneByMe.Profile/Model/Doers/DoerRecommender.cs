using System.Collections.Generic;
using System.Linq;
using DoneByMe.Profile.Model.DoerSkills;
using DoneByMe.Profile.Model.Ranking;
using VaughnVernon.Mockroservices;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Profile.Model.Doers
{
    public class DoerRecommender : SourcedEntity<DomainEvent>
    {
        private RankingCalculator rankingCalculator;
        
        public Id ProposalId { get; private set; }
        public IEnumerable<RecommendedDoer> RecommendedDoers { get; private set; }
        
        public DoerRecommender(IEnumerable<DomainEvent> stream, int streamVersion)
            : base(stream, streamVersion)
        {
        }

        public DoerRecommender()
        {
            rankingCalculator = new RankingCalculator();
        }
        
        public void RecommandeDoers(string proposalId, string[] keywords, string locality)
        {
            var skillsClassification = SkillClassification.From(Keyword.From(keywords).ToArray());
            var ranking = rankingCalculator.RankAmong(skillsClassification, Locality.From(locality), new List<Doer>());
            Apply(new DoersRecommended(proposalId, ranking.doerRanks.Select(r 
                => new RecommendedDoer(r.Doer.Id, r.Rank.Preferredness == Ranking.Ranking.Preferredness.Preferred)), locality));
        }

        public void When(DoersRecommended doersRecommended)
        {
            ProposalId = Id.FromExisting(doersRecommended.ProposalId);
            RecommendedDoers = doersRecommended.Doers;
        }
    }
}