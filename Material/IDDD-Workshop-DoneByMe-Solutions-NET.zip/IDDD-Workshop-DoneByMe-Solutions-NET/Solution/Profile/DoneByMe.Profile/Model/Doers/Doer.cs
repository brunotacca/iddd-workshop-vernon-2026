﻿using System;
using DoneByMe.Profile.Model.DoerSkills;

namespace DoneByMe.Profile.Model.Doers
{
    public class Doer
    {
        public string Id { get; private set; }
        public Skills Skills { get; private set; }

        public static Doer With(Skills skills) => new Doer(skills);

        public void DeclareNew(Skill skill) => Skills = Skills.Declare(skill);

        public Rank RankFor(SkillClassification classification) => Skills.RankFor(classification);

        private Doer(Skills skills)
        {
            Id = Guid.NewGuid().ToString();
            Skills = skills;
        }
    }
}
