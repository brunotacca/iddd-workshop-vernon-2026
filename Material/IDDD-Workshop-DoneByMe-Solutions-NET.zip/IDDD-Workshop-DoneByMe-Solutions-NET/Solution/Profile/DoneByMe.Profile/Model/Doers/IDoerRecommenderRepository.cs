﻿namespace DoneByMe.Profile.Model.Doers
{
    public interface IDoerRecommenderRepository
    {
		DoerRecommender DoerRecommenderOf(Id id);
		void Save(DoerRecommender doerRecommender);
	}
}
