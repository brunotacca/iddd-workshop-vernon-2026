﻿using DoneByMe.Profile.Model.Doers;

namespace DoneByMe.Profile.Infra.Persistence
{
    public class Repositories
    {
		private static IDoerRecommenderRepository doerRecommenderRepository;

		public static IDoerRecommenderRepository DoerRecommenderRepository
		{
			get
			{
				if (doerRecommenderRepository == null)
				{
					doerRecommenderRepository = new JournalDoerRecommenderRepository();
				}
				return doerRecommenderRepository;
			}
		}
    }
}
