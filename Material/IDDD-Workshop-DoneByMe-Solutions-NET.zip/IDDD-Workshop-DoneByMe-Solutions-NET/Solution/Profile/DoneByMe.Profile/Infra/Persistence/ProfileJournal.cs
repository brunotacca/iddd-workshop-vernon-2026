﻿using VaughnVernon.Mockroservices.Journals;

namespace DoneByMe.Profile.Infra.Persistence
{
    public class ProfileJournal
    {
		public static Journal Journal;
  
		public static void Start() => Journal = Journal.Open("donebyme-profile");

		public static void Stop() => Journal.Close();
    }
}
