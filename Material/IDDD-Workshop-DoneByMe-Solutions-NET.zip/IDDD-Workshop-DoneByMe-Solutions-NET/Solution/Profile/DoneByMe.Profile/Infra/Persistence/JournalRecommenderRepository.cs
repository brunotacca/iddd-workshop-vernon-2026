﻿using DoneByMe.Profile.Model;
using DoneByMe.Profile.Model.Doers;
using VaughnVernon.Mockroservices.Journals;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Profile.Infra.Persistence
{
	public class JournalDoerRecommenderRepository : Repository, IDoerRecommenderRepository
	{
		private readonly Journal journal;
		private readonly EntryStreamReader reader;
		public DoerRecommender DoerRecommenderOf(Id id)
		{
			var stream = reader.StreamFor(id.Value);

			return new DoerRecommender(ToSourceStream<DomainEvent>(stream.Stream), stream.StreamVersion);
		}

		public void Save(DoerRecommender doerRecommender)
			=> journal.Write(doerRecommender.ProposalId.Value, doerRecommender.NextVersion, ToBatch(doerRecommender.Applied));


		internal JournalDoerRecommenderRepository()
		{
			journal = Journal.Open("donebyme-profile");
			reader = journal.StreamReader();
		}
	}
}
