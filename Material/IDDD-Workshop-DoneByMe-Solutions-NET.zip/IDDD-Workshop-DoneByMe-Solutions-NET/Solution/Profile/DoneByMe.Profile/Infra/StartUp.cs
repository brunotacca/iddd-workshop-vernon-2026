﻿using DoneByMe.Profile.Infra.Messaging;
using DoneByMe.Profile.Infra.Persistence;

namespace DoneByMe.Profile.Infra
{
	public class StartUp
    {
			public static void Start()
			{
				ProfileJournal.Start();
				ProfileJournalPublisher.Start();
				AllTopicSubscriber.Start();
			}
    }
}
