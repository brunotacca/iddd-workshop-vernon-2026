﻿using DoneByMe.Profile.Application;

namespace DoneByMe.Profile.Infra
{
	public class API
	{
		private static DoerRecommendation doerRecommendation;
		public static DoerRecommendation DoerRecommendation
        {
			get
			{
				if (doerRecommendation == null)
				{
					doerRecommendation = new DoerRecommendation();
				}
				return doerRecommendation;
			}
		}
	}
}
