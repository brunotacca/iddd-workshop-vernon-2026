﻿using DoneByMe.Profile.Infra.Persistence;
using VaughnVernon.Mockroservices.Journals;
using VaughnVernon.Mockroservices.MessageBuses;

namespace DoneByMe.Profile.Infra.Messaging
{
	public class ProfileJournalPublisher
	{
		private static JournalPublisher journalPublisher;

		public static void Start()
		{
			var messageBus = MessageBus.Start("donebyme");
			var topic = messageBus.OpenTopic("all");

			journalPublisher =
				JournalPublisher.From(
					ProfileJournal.Journal.Name,
					messageBus.Name,
					topic.Name);
		}

		public static void Stop() => journalPublisher.Close();
	}
}
