﻿using DoneByMe.Profile.Model.Doers;
using VaughnVernon.Mockroservices;
using VaughnVernon.Mockroservices.Exchanges;
using VaughnVernon.Mockroservices.MessageBuses;

namespace DoneByMe.Profile.Infra.Messaging
{
	public class AllTopicSubscriber : ISubscriber
	{
		private static AllTopicSubscriber instance;

		public static AllTopicSubscriber Start()
		{
			if (instance == null)
			{
				instance = new AllTopicSubscriber();
			}
			return instance;
		}

		public void Handle(Message message)
		{
            var reader = MessageExchangeReader.From(message);
            switch (message.SimpleTypeName())
            {
                case "DoneByMe.Matching.Model.Proposals.RecommendDoers":
	                API.DoerRecommendation.RecommandDoers(reader.PayloadStringValue("processIdValue"),
		                reader.PayloadStringArrayValue("keywords"),
		                reader.PayloadStringValue("locality"));
	                var recommender = new DoerRecommender();
	                break;
            }
        }

		private AllTopicSubscriber()
		{
			var messageBus = MessageBus.Start("donebyme");
			var allTopic = messageBus.OpenTopic("all");

			allTopic.Subscribe(this);
		}
	}
}
