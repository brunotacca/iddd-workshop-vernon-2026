﻿// Application Service

using DoneByMe.Profile.Infra.Persistence;
using DoneByMe.Profile.Model.Doers;

namespace DoneByMe.Profile.Application
{
	public class DoerRecommendation
    {
		private readonly DoerRecommender doerRecommender = new();

		public void RecommandDoers(string proposalId, string[] keywords, string locality)
		{
			doerRecommender.RecommandeDoers(proposalId, keywords, locality);
			Repositories.DoerRecommenderRepository.Save(doerRecommender);
		}
    }
}
