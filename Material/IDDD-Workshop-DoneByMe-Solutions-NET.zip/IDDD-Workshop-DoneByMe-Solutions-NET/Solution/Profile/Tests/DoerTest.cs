using DoneByMe.Profile.Model.Doers;
using DoneByMe.Profile.Model.DoerSkills;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
    public class DoerTest
    {
        [TestMethod]
        public void TestThatMarcHasScoreOf195()
        {
            var marcDoer = MarcDoer();
            var windowWashing = WindowWashing();

            var rank = marcDoer.RankFor(windowWashing);

            Assert.AreEqual(1.95, rank.Total);
        }
        
        private SkillClassification WindowWashing() {
            return SkillClassification.From(
                Keyword.Is("#windows"),
                Keyword.Is("#washing"));
        }
        
        private Doer MarcDoer() {
            var doer = Doer.With(Skills.StartingWith(
                Skill.Of(
                    SkillClassification.From(
                        Keyword.Is("#windows"),
                        Keyword.Is("#washing")),
                    Qualifications.Of(
                        Qualification.Licensed,
                        Qualification.Certified,
                        Qualification.Bonded),
                    Rate.FlatRateOf(10000))));
    
            return doer;
        }
    }
}