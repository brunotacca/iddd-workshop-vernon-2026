using System.Collections.Generic;
using System.Linq;
using DoneByMe.Profile.Model;
using DoneByMe.Profile.Model.Doers;
using DoneByMe.Profile.Model.DoerSkills;
using DoneByMe.Profile.Model.Ranking;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
    public class RankingCalculatorTest
    {
        [TestMethod]
        public void TestThatMarcHasHigherScoreThanDaniel()
        {
            var marcDoer = MarcDoer();
            var danielDoer = DanielDoer();
            var windowWashing = WindowWashing();

            var rankingCaluclator = new RankingCalculator();

            var ranking = rankingCaluclator.RankAmong(windowWashing, new Locality("Krakow"),
                new List<Doer> {marcDoer, danielDoer});

            var marcDoerRank = ranking.doerRanks.First();
            var danielDoerRank = ranking.doerRanks.Last();
            
            Assert.AreEqual(1.95, marcDoerRank.Rank.Total);
            Assert.AreEqual(1.85, danielDoerRank.Rank.Total);
        }
        
        private SkillClassification WindowWashing() {
            return SkillClassification.From(
                Keyword.Is("#windows"),
                Keyword.Is("#washing"));
        }
        
        private Doer MarcDoer() {
            var doer = Doer.With(Skills.StartingWith(
                Skill.Of(
                    SkillClassification.From(
                        Keyword.Is("#windows"),
                        Keyword.Is("#washing")),
                    Qualifications.Of(
                        Qualification.Licensed,
                        Qualification.Certified,
                        Qualification.Bonded),
                    Rate.FlatRateOf(10000))));
    
            return doer;
        }
        
        private Doer DanielDoer() {
            var doer = Doer.With(Skills.StartingWith(
                Skill.Of(
                    SkillClassification.From(
                        Keyword.Is("#windows"),
                        Keyword.Is("#washing")),
                    Qualifications.Of(
                        Qualification.Certified,
                        Qualification.Bonded,
                        Qualification.Years),
                    Rate.FlatRateOf(10000))));
    
            return doer;
        }
    }
}