﻿using DoneByMe.Profile.Model.Doers;
using DoneByMe.Profile.Model.DoerSkills;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
    public class FluentDoerSkillsTest
    {
        [TestMethod]
        public void TestThatFluentModelRocks()
        {
            var skill =
                Skill.Of(
                    SkillClassification.From(
                        Keyword.Is("#windows"),
                        Keyword.Is("#washing"),
                        Keyword.Is("#inside"),
                        Keyword.Is("#outside"),
                        Keyword.Is("#extra-tall")),
                    Qualifications.Of(
                        Qualification.Certified,
                        Qualification.Bonded,
                        Qualification.Licensed,
                        Qualification.Years),
                    Rate.FlatRateOf(10000));

            Assert.IsNotNull(skill);

            Assert.AreEqual(skill.Classification,
                SkillClassification.From(
                    Keyword.Is("#windows"),
                    Keyword.Is("#washing"),
                    Keyword.Is("#inside"),
                    Keyword.Is("#outside"),
                    Keyword.Is("#extra-tall")));

            var doerSkills = Skills.StartingWith(skill);

            Assert.IsTrue(doerSkills.Declares(skill));
        }

        public void TestThatMarcHasScoreOf195()
        {
            var marc = MarcDoer();
            var classification =
                WindowWashing();
            //var rank = marc.RankFor(classification);
            //Assert.Equal(1.95D, rank.Total, 0);
        }

        private SkillClassification WindowWashing()
        {
            return SkillClassification.From(
                Keyword.Is("#windows"),
                Keyword.Is("#washing"));
        }

        private Doer MarcDoer()
        {
            var doer = Doer.With(Skills.StartingWith(
                Skill.Of(
                    SkillClassification.From(
                        Keyword.Is("#windows"),
                        Keyword.Is("#washing")),
                    Qualifications.Of(
                        Qualification.Licensed,
                        Qualification.Certified,
                        Qualification.Bonded),
                    Rate.FlatRateOf(10000))));

            return doer;
        }
    }
}