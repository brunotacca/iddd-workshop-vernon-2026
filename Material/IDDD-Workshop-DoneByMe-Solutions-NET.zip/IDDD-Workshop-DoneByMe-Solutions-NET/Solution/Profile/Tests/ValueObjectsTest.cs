﻿using DoneByMe.Profile.Model.DoerSkills;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
    public class ValueObjectsTest
    {
        [TestMethod]
        public void TestThatValuesCompose()
        {
            var doerSkill =
                    Skill.Of(
                            SkillClassification.From(
                                    Keyword.Is("#windows"),
                                    Keyword.Is("#washing"),
                                    Keyword.Is("#inside"),
                                    Keyword.Is("#outside"),
                                    Keyword.Is("#extra-tall"),
                                    Keyword.Is("#count=25")),
                            Qualifications.Of(
                                    Qualification.Certified,
                                    Qualification.Bonded,
                                    Qualification.Licensed,
                                    Qualification.Years),
                            Rate.FlatRateOf(10000));

            Assert.IsNotNull(doerSkill);

            Assert.AreEqual(doerSkill.Classification,
                    SkillClassification.From(
                            Keyword.Is("#windows"),
                            Keyword.Is("#washing"),
                            Keyword.Is("#inside"),
                            Keyword.Is("#outside"),
                            Keyword.Is("#extra-tall"),
                            Keyword.Is("#count=25")));

            Assert.AreEqual(doerSkill.Qualifications,
                            Qualifications.Of(
                                    Qualification.Certified,
                                    Qualification.Bonded,
                                    Qualification.Licensed,
                                    Qualification.Years));

            Assert.AreEqual(doerSkill.Rate, Rate.FlatRateOf(10000));
        }
    }
}
