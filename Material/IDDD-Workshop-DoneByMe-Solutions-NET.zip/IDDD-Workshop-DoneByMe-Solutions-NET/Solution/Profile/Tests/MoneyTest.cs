﻿using DoneByMe.Profile.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
    public class MoneyTest
    {
        [TestMethod]
        public void TestThatMoneyScales()
        {
            var money1 = Money.Of(1234599);
            Assert.AreEqual("12345.99", money1.ScaledBy(2));
            var money2 = Money.Of(1234567995);
            Assert.AreEqual("1234567.995", money2.ScaledBy(3));
        }
    }
}
