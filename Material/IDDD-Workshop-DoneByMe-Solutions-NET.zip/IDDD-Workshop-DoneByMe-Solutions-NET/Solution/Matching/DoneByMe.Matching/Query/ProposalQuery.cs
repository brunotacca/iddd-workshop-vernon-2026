﻿using System.Collections.Generic;
using DoneByMe.Matching.Infra.Projections;

namespace DoneByMe.Matching.Query
{
    public class ProposalQuery
    {
		public ProposalView Proposal(string proposalId) => ProposalView.Get(proposalId);

		public IEnumerable<ProposalView> Proposals(string clientId) => ProposalView.GetAllFor(clientId);
    }
}
