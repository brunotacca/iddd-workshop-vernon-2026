﻿using System;
using VaughnVernon.Mockroservices.MessageBuses;
using VaughnVernon.Mockroservices.Model;
using VaughnVernon.Mockroservices.Serializations;

namespace DoneByMe.Matching.Infra.Projections
{
    public abstract class Projection
    {
		protected DomainEvent ToEvent(Message message)
		{
            var eventType = Type.GetType(message.Type);
            var domainEvent = (DomainEvent) Serialization.Deserialize(message.Payload, eventType);
			return domainEvent;
		}
	}
}
