﻿using DoneByMe.Matching.Infra.Persistence;
using VaughnVernon.Mockroservices.Journals;
using VaughnVernon.Mockroservices.MessageBuses;

namespace DoneByMe.Matching.Infra.Messaging
{
	public class MatchingJournalPublisher
	{
		private static JournalPublisher journalPublisher;

		public static void Start()
		{
			var messageBus = MessageBus.Start("donebyme");
			var topic = messageBus.OpenTopic("all");

			journalPublisher =
				JournalPublisher.From(
					MatchingJournal.Journal.Name,
					messageBus.Name,
					topic.Name);
		}

		public static void Stop() => journalPublisher.Close();
	}
}
