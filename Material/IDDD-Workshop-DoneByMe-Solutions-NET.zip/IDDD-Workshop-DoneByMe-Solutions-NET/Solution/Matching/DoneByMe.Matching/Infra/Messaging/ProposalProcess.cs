using System;
using System.Collections.Generic;
using System.Linq;
using DoneByMe.Matching.Model;
using DoneByMe.Matching.Model.Proposals;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Infra.Messaging
{
    public class ProposalProcess : SourcedEntity<Command>
    {
        private bool analyzePricing = false;
        private bool recommendDoers = false;
        private bool availabilityLocated = false;
        
        public Id ProposalId { get; }

        public bool IsCompleted => analyzePricing && recommendDoers && availabilityLocated;

        public ProposalProcess(Id proposalId) => ProposalId = proposalId;

        public ProposalProcess(IEnumerable<Command> commands, int streamStreamVersion) 
            : base(commands, streamStreamVersion)
        {
        }

        public void OnProposalSubmitted(string[] keywords, DateTime completedBy, long price, string locality)
        {
            if (!analyzePricing)
            {
                Apply(new AnalyzePricing(ProposalId, keywords, completedBy, price));
            }

            if (!recommendDoers)
            {
                Apply(new RecommendDoers(ProposalId, keywords, locality));
            }
            
            if (!availabilityLocated)
            {
                Apply(new LocateAvailability(ProposalId, Enumerable.Empty<Doer>()));
            }
        }

        public void OnPricingVerified()
        {
            // commands.VerifyPricing(proposalId.Value);
            // Apply(new RecommendDoers(processId.Value));
        }

        public void OnPricingRejected(long suggestedPrice)
        {
            // var proposal = repository.ProposalOf(proposalId);
            // proposal.DenyPricing(suggestedPrice);
            // repository.Save(proposal);
            // EndProcess();
        }

        public void OnDoersRecommended(IEnumerable<Doer> doers)
        {
            // var proposal = repository.ProposalOf(proposalId);
            // proposal.RecommendDoers(doers);
            // repository.Save(proposal);
            // Apply(new LocateAvailability());
        }

        public void OnAvailabilityLocated(IEnumerable<Doer> availableDoers)
        {
            // var proposal = repository.ProposalOf(proposalId);
            // proposal.AvailableDoers(availableDoers);
            // repository.Save(proposal);
            // EndProcess();
        }


        public void When(AnalyzePricing command)
        {
        }

        public void When(RecommendDoers command)
        {
        }

        public void When(LocateAvailability command)
        {
        }
        
        // public void Handle(Message message)
        // {
        //     var reader = MessageExchangeReader.From(message);
        //     if (reader.Type == "ProposalSubmitted")
        //     {
        //         OnProposalSubmitted(reader.PayloadStringValue("proposalId"),
        //             reader.PayloadStringArrayValue("keywords"),
        //             reader.PayloadDateTimeValue("completedBy"),
        //             reader.PayloadLongValue("price"));
        //         
        //     }
        //
        //     if (reader.Type == "PricingVerified")
        //     {
        //         OnPricingVerified();
        //     }
        //     
        //     
        // }
        
        private void EndProcess()
        {
            // GO TO HELL
        }
    }
}