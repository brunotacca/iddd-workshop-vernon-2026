// Copyright © 2012-2021 VLINGO LABS. All rights reserved.
//
// This Source Code Form is subject to the terms of the
// Mozilla Public License, v. 2.0. If a copy of the MPL
// was not distributed with this file, You can obtain
// one at https://mozilla.org/MPL/2.0/.

using System;
using System.Collections.Generic;
using DoneByMe.Matching.Infra.Persistence;
using DoneByMe.Matching.Model;
using DoneByMe.Matching.Model.Proposals;
using VaughnVernon.Mockroservices.Exchanges;
using VaughnVernon.Mockroservices.Journals;
using VaughnVernon.Mockroservices.MessageBuses;
using VaughnVernon.Mockroservices.Model;
using VaughnVernon.Mockroservices.Serializations;

namespace DoneByMe.Matching.Infra.Messaging
{
    public class MatchingProcess : ISubscriber
    {
        private readonly Journal journal = MatchingJournal.Journal;
        
        public static void Start()
        {
            var process = new MatchingProcess();
            
            var messageBus = MessageBus.Start("donebyme");
            var allTopic = messageBus.OpenTopic("all");
            allTopic.Subscribe(process);
        }

        // Used by Start()
        private MatchingProcess()
        {
        }

        // Message Handler
        public void Handle(Message message)
        {
            var reader = MessageExchangeReader.From(message);
            switch (reader.Type)
            {
                // from Matching
                case "DoneByMe.Matching.Model.Proposals.ProposalSubmitted":
                    OnProposalSubmitted(
                        reader.PayloadStringValue("proposalId"),
                        reader.PayloadStringArrayValue("keywords"),
                        reader.PayloadDateTimeValue("completedBy"),
                        reader.PayloadLongValue("price"));
                    break;
                
                // from Matching
                case "DoneByMe.Matching.Model.Proposals.ProposalResubmitted":
                    OnProposalResubmitted(
                        reader.PayloadStringValue("proposalId"),
                        reader.PayloadStringArrayValue("keywords"),
                        reader.PayloadDateTimeValue("completedBy"),
                        reader.PayloadLongValue("price"));
                    break;
                
                // from Pricing
                case "DoneByMe.Pricing.Model.Analysis.PricingVerified":
                    OnPricingVerified(reader.PayloadStringValue("proposalId"));
                    break;
                
                // from Pricing
                case "DoneByMe.Pricing.Model.Analysis.PricingRejected":
                    OnPricingRejected(reader.PayloadStringValue("proposalId"),
                        reader.PayloadLongValue("suggestedPrice"));
                    break;
                
                // from Matching
                case "DoneByMe.Matching.Model.Proposals.PricingVerified":
                    // TODO: This is wrong because PricingVerified doesn't have keywords and locality properties
                    OnPricingVerified(reader.PayloadStringValue("proposalId"),
                        Array.Empty<string>(), string.Empty);
                    break;

                // from Matching
                case "DoneByMe.Matching.Model.Proposals.PricingDenied":
                    OnPricingDenied(reader.PayloadStringValue("proposalId"),
                        reader.PayloadIntegerValue("resubmissionCount"),
                        reader.PayloadLongValue("suggestedPrice"));
                    break;
                
                // from Profiles
                case "DoneByMe.Profile.Model.Doers.DoersRecommended":
                    OnDoersRecommended(
                        reader.PayloadStringValue("proposalId"),
                        Serialization.Deserialize<DoersRecommended>(message.Payload).Doers);
                    break;
                
                // from Matching
                case "DoneByMe.Matching.Model.Proposals.SkilledDoersPooled":
                    OnSkilledDoersPooled(reader.PayloadStringValue("proposalId"),
                        Serialization.Deserialize<DoersRecommended>(message.Payload).Doers);
                    break;
                
                // from Scheduling
                case "AvailabilityLocated":
                    OnAvailabilityLocated(reader.PayloadStringValue("proposalId"),
                        Serialization.Deserialize<DoersRecommended>(message.Payload).Doers);
                    break;
                
                // From Matching
                case "DoneByMe.Matching.Model.Proposals.SkilledDoersMerged":
                    OnSkilledDoersMerged(reader.PayloadStringValue("proposalId"),
                        Serialization.Deserialize<DoersRecommended>(message.Payload).Doers);
                    break;
                // From Doers Mobile App
                case "donebyme.doersontherun.ProposalAccepted": 
                    OnProposalAccepted(reader.PayloadStringValue("proposalId"),
                        reader.PayloadStringValue("doerId"));
                    break;
            }            
        }
        
        // Process Behavior
        private void OnProposalSubmitted(string proposalId, string[] keywords, DateTime completedBy, long price) => 
            Append(new AnalyzePricing(proposalId, keywords, completedBy, price));
        
        private void OnProposalResubmitted(string proposalId, string[] keywords, DateTime completedBy, long price) => 
            Append(new AnalyzePricing(proposalId, keywords, completedBy, price));

        private void OnPricingVerified(string proposalId) => API.ProposalCommands.VerifyPricing(proposalId);

        private void OnPricingRejected(string proposalId, long suggestedPrice) => 
            API.ProposalCommands.DenyPricing(proposalId, suggestedPrice);

        private void OnPricingVerified(string id, string[] keywords, string locality) => 
            Append(new RecommendDoers(Id.FromExisting(id), keywords, locality));

        private void OnPricingDenied(string id, int resubmissionCount, long suggestedPrice) => 
            API.ProposalCommands.HandleUnderpriced(id, resubmissionCount, suggestedPrice);

        private void OnDoersRecommended(string proposalId, IEnumerable<Doer> doers) => 
            API.ProposalCommands.PoolSkilledDoers(proposalId, doers);

        private void OnSkilledDoersPooled(string proposalId, IEnumerable<Doer> doers) => 
            Append(new LocateAvailability(proposalId, doers));

        private void OnAvailabilityLocated(string proposalId, IEnumerable<Doer> doers) => 
            API.ProposalCommands.MergeSkilledDoers(proposalId, doers);
        
        private void OnSkilledDoersMerged(string proposalId, IEnumerable<Doer> doers) => 
            Append(new NotifyAvailableDoers(proposalId, doers));

        private void OnProposalAccepted(string proposalId, string doerId) =>
            API.ProposalCommands.Accept(proposalId, doerId);

        private void Append(Command command)
        {
            var body = Serialization.Serialize(command);
            journal.Write(command.Id, command.Version, EntryBatch.Of(command.GetType().AssemblyQualifiedName!, body));
        }
    }
}