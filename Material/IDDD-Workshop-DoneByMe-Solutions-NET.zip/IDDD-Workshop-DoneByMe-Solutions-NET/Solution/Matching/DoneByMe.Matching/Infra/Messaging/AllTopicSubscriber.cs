﻿using System;
using DoneByMe.Matching.Infra.Persistence;
using DoneByMe.Matching.Model;
using DoneByMe.Matching.Model.Proposals;
using VaughnVernon.Mockroservices.Exchanges;
using VaughnVernon.Mockroservices.MessageBuses;
using VaughnVernon.Mockroservices.Model;
using VaughnVernon.Mockroservices.Serializations;

namespace DoneByMe.Matching.Infra.Messaging
{
    public class AllTopicSubscriber : ISubscriber
    {
		private static AllTopicSubscriber instance;

		public static AllTopicSubscriber Start()
		{
			if (instance == null)
			{
				instance = new AllTopicSubscriber();
			}
			return instance;
		}

		public void Handle(Message message)
		{
            var reader = MessageExchangeReader.From(message);
            ProposalProcess proposalProcess;
            switch (message.SimpleTypeName()) 
            {
	            case "DoneByMe.Matching.Model.Proposals.ProposalSubmitted":
		            proposalProcess = new ProposalProcess(Id.FromExisting(reader.PayloadStringValue("proposalId")));
		            proposalProcess.OnProposalSubmitted(
			            reader.PayloadStringArrayValue("keywords"),
			            reader.PayloadDateTimeValue("completedBy"),
			            reader.PayloadLongValue("price"),
			            reader.PayloadStringValue("clientLocality"));
		            Repositories.ProposalProcess.Save(proposalProcess);
		            break;
	            case "DoneByMe.Profile.Model.Doers.DoersRecommended":
		            proposalProcess = Repositories.ProposalProcess.ProposalProcessOf(Id.FromExisting(reader.PayloadStringValue("proposalId")));
		            var recommendedDoers = Serialization.Deserialize<DoersRecommended>(message.Payload);
		            proposalProcess.OnDoersRecommended(recommendedDoers.Doers);
		            break;
                case "DoneByMe.Pricing.Model.Analysis.PricingVerified":
                    API.ProposalCommands.VerifyPricing(
                        reader.PayloadStringValue("originatorId"));
                    break;
                case "DoneByMe.Pricing.Model.Analysis.PricingRejected":
    				API.ProposalCommands.DenyPricing(
                        reader.PayloadStringValue("originatorId"),
                        reader.PayloadLongValue("suggestedPrice"));
                    break;
                case "DoneByMe.Scheduling.Model.Availability.SchedulingVerified":
	                API.ProposalCommands.VerifyScheduling(
		                reader.PayloadStringValue("originatorId"));
	                break;
                case "DoneByMe.Scheduling.Model.Availability.SchedulingRejected":
	                API.ProposalCommands.DenyScheduling(
		                reader.PayloadStringValue("originatorId"),
		                new DateTime(reader.PayloadLongValue("suggestedCompletedBy")));
	                break;
			}
		}

		private AllTopicSubscriber()
		{
			var messageBus = MessageBus.Start("donebyme");
			var allTopic = messageBus.OpenTopic("all");

			allTopic.Subscribe(this);
		}
		
		private Command ToCommand(Message message)
		{
			try
			{
				var type = Type.GetType(message.Type);
				var command = (Command)Serialization.Deserialize(message.Payload, type);
				return command;
			} 
			catch (Exception e)
			{
				throw new InvalidOperationException($"Message is not a command: {message.Type}", e);
			}
		}
	}
}
