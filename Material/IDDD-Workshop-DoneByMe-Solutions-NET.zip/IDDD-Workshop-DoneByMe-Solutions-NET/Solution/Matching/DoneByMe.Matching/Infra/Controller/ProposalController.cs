﻿using System;
using System.Collections.Generic;
using DoneByMe.Matching.Infra.Projections;
using DoneByMe.Matching.Query;

namespace DoneByMe.Matching.Infra.Controller
{
    public class ProposalController
    {
		public ProposalView Get(string proposalId) => new ProposalQuery().Proposal(proposalId);

		public IEnumerable<ProposalView> GetForClient(string clientId) => new ProposalQuery().Proposals(clientId);

		public void Submit(
			string clientId,
			string clientLocality,
			string summary,
			string description,
			List<string> keywords,
			DateTime completedBy,
			Dictionary<int, string> steps,
			long price) =>
			API.ProposalCommands
				.SubmitProposal(
					clientId,
					clientLocality,
					summary,
					keywords,
					description,
					completedBy,
					steps,
					price);
    }
}
