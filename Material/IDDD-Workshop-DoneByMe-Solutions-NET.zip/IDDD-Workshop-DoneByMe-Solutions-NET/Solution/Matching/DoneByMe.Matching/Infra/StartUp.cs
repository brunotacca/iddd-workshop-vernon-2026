﻿using DoneByMe.Matching.Infra.Messaging;
using DoneByMe.Matching.Infra.Persistence;

namespace DoneByMe.Matching.Infra
{
    public class StartUp
    {
		public static void Start()
		{
			MatchingJournal.Start();
			// ProposalProcess.Start();
			MatchingJournalPublisher.Start();
			//AllTopicSubscriber.Start();
			MatchingProcess.Start();
		}
    }
}
