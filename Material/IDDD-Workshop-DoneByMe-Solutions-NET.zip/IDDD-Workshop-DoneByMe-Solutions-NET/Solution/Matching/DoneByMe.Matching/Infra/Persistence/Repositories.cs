﻿using DoneByMe.Matching.Model.Proposals;

namespace DoneByMe.Matching.Infra.Persistence
{
    public class Repositories
    {
		private static IProposalRepository proposalRepository;
		private static JournalProposalProcessRepository proposalProcess;

		public static IProposalRepository ProposalRepository
		{
			get
			{
				if (proposalRepository == null)
				{
					proposalRepository = new JournalProposalRepository();
				}
				return proposalRepository;
			}
		}
		
		public static JournalProposalProcessRepository ProposalProcess
		{
			get
			{
				if (proposalProcess == null)
				{
					proposalProcess = new JournalProposalProcessRepository();
				}
				return proposalProcess;
			}
		}
	}
}
