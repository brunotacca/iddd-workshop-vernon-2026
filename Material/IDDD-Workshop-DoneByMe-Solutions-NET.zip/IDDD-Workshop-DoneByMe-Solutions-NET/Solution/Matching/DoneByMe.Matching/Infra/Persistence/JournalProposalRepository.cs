﻿using DoneByMe.Matching.Model;
using DoneByMe.Matching.Model.Proposals;
using VaughnVernon.Mockroservices.Journals;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Infra.Persistence
{
	public class JournalProposalRepository : Repository, IProposalRepository
	{
		private readonly Journal journal;
		private readonly EntryStreamReader reader;

		public Proposal ProposalOf(Id id)
		{
			var stream = reader.StreamFor(StreamNameBuilder.BuildStreamNameFor<Proposal>(id.Value));

            return new Proposal(ToSourceStream<DomainEvent>(stream.Stream), stream.StreamVersion);
		}

		public void Save(Proposal proposal) 
			=> journal.Write(StreamNameBuilder.BuildStreamNameFor<Proposal>(proposal.Id.Value), proposal.NextVersion, ToBatch(proposal.Applied));

		internal JournalProposalRepository()
		{
			journal = Journal.Open("donebyme-matching");
			reader = journal.StreamReader();
		}
	}
}
