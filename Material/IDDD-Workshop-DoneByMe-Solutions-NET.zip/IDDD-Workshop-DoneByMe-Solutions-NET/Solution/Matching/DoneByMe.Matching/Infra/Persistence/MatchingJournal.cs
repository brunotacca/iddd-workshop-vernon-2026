﻿using VaughnVernon.Mockroservices.Journals;

namespace DoneByMe.Matching.Infra.Persistence
{
    public class MatchingJournal
    {
		public static Journal Journal;
  
		public static void Start() => Journal = Journal.Open("donebyme-matching");

		public static void Stop() => Journal.Close();
    }
}
