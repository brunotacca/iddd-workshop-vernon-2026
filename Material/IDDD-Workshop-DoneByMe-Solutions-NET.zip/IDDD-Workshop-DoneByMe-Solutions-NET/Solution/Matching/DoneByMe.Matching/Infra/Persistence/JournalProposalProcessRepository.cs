using DoneByMe.Matching.Infra.Messaging;
using DoneByMe.Matching.Model;
using VaughnVernon.Mockroservices.Journals;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Infra.Persistence
{
    public class JournalProposalProcessRepository : Repository
    {
        private readonly Journal journal;
        private readonly EntryStreamReader reader;

        internal JournalProposalProcessRepository()
        {
            journal = Journal.Open("donebyme-matching");
            reader = journal.StreamReader();
        }

        public ProposalProcess ProposalProcessOf(Id id)
        {
            var stream = reader.StreamFor(StreamNameBuilder.BuildStreamNameFor<ProposalProcess>(id.Value));

            return new ProposalProcess(ToSourceStream<Command>(stream.Stream), stream.StreamVersion);
        }

        public void Save(ProposalProcess proposalProcess)
        {
            journal.Write(
                StreamNameBuilder.BuildStreamNameFor<ProposalProcess>(proposalProcess.ProposalId),
                proposalProcess.NextVersion,
                ToBatch(proposalProcess.Applied));
        }
    }
}