﻿namespace DoneByMe.Matching.Model
{
    public class Summary
    {
		public string Text { get; }
  
		public static Summary Has(string text) => new Summary(text);

		public override int GetHashCode() => Text.GetHashCode();

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Summary))
			{
				return false;
			}
    
			return Text.Equals(((Summary) other).Text);
		}

		public override string ToString() => $"Summary[Text={Text}]";

		private Summary(string text) => Text = text;
    }
}
