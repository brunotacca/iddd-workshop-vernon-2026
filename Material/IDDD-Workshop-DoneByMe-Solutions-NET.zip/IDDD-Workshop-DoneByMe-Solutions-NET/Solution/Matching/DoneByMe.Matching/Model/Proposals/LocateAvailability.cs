using System.Collections.Generic;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class LocateAvailability : Command
    {
        public string ProposalId { get; }
        public IEnumerable<Doer> Doers { get; }

        public LocateAvailability(string proposalId, IEnumerable<Doer> doers) : base(proposalId)
        {
            ProposalId = proposalId;
            Doers = doers;
        }
    }
}