﻿namespace DoneByMe.Matching.Model.Proposals
{
    public enum Spec
    {
        PricingDenied,
        PricingVerified,
        SchedulingDenied,
        SchedulingVerified,
        Submitted,
        Resubmitted,
        DoersRecommended,
        Matched,
        DoersAvailable
    }
}
