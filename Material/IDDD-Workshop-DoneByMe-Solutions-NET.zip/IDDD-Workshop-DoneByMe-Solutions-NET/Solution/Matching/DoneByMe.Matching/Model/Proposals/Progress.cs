﻿using System.Collections.Generic;

namespace DoneByMe.Matching.Model.Proposals
{
    public class Progress
    {
        public static readonly Progress None = new Progress();
        public static readonly Progress Submitted = new Progress(Spec.Submitted);
        public static Progress Resubmitted = new Progress(Spec.Resubmitted);

		internal readonly HashSet<Spec> Specs;

		public bool IsAcceptable => WasSubmitted && WasPricingVerified && WasSchedulingVerified;

		public bool IsUnacceptable => WasSubmitted && WasPricingDenied || WasSchedulingDenied;

		public bool WasMatched => Specs.Contains(Spec.Matched);
		
		public bool DoersRecommended => Specs.Contains(Spec.DoersRecommended);
		
		public bool DoersAvailable => Specs.Contains(Spec.DoersAvailable);

		public bool WasPricingDenied => Specs.Contains(Spec.PricingDenied);

		public bool WasPricingVerified => Specs.Contains(Spec.PricingVerified);

		public bool WasSchedulingDenied => Specs.Contains(Spec.SchedulingDenied);

		public bool WasSchedulingVerified => Specs.Contains(Spec.SchedulingVerified);

		public bool WasSubmitted => Specs.Contains(Spec.Submitted);

		public override int GetHashCode() => Specs.GetHashCode();

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Progress)) {
				return false;
			}
    
			var otherProgress = (Progress) other;
    
			return Specs.Equals(otherProgress.Specs);
		}

		public override string ToString() => $"Progress[Specs={Specs}]";
		
		internal Progress Matched() => WithNewSpec(Spec.Matched);

		internal Progress DeniedForPricing() => WithNewSpec(Spec.PricingDenied);

		internal Progress DeniedForScheduling() => WithNewSpec(Spec.SchedulingDenied);

		internal Progress SubmittedByClient() => WithOnlySpec(Spec.Submitted);

		internal Progress VerifiedForPricing() => WithNewSpec(Spec.PricingVerified);

		internal Progress VerifiedForScheduling() => WithNewSpec(Spec.SchedulingVerified);

		private Progress WithNewSpec(Spec spec)
		{
			var newSpecs = new HashSet<Spec>(Specs);
			newSpecs.Add(spec);
			return new Progress(newSpecs);
		}

		private Progress WithOnlySpec(Spec spec)
		{
			var newSpecs = new HashSet<Spec>();
			newSpecs.Add(spec);
			return new Progress(newSpecs);
		}

		private Progress() => Specs = new HashSet<Spec>();

		private Progress(Spec spec)
		{
			Specs = new HashSet<Spec>();
			Specs.Add(spec);
		}

		internal Progress(HashSet<Spec> specs) => Specs = specs;
    }
}
