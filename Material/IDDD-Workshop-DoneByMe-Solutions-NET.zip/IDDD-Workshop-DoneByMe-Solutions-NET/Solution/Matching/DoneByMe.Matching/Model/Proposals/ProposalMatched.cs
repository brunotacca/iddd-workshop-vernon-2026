using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class ProposalMatched : DomainEvent
    {
        public ProposalMatched(Proposal proposal, Doer doer)
        {
            ProposalId = proposal.Id.Value;
            Clientid = proposal.Client.Id.Value;
            DoerId = doer.Id.Value;
            Preferred = doer.Preferred;
        }
        
        public string ProposalId { get; }
        
        public string Clientid { get; }
        
        public string DoerId { get; }
        
        public bool Preferred { get; }
    }
}