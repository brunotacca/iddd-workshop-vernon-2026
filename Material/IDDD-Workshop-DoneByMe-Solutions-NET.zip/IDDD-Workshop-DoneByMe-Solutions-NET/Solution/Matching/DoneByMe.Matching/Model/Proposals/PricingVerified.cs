﻿using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
	public class PricingVerified : DomainEvent
	{
		public string ProposalId { get; private set; }
		public string ClientId { get; private set; }
		public long Price { get; private set; }

        public PricingVerified(
	        Id proposalId,
	        Client client,
	        Expectations expectations)
        {
	        ProposalId = proposalId.Value;
	        ClientId = client?.Id.Value;
	        if (expectations != null) Price = expectations.Price;
        }
	}
}
