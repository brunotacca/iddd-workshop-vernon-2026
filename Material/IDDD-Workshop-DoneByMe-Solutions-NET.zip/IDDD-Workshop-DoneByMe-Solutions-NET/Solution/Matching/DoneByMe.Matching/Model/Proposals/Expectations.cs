﻿using System;
using System.Collections.Generic;

namespace DoneByMe.Matching.Model.Proposals
{
	public sealed class Expectations
	{
		public Description Description { get; }
		public DateTime CompletedBy { get; }
		public Keywords Keywords { get; private set; }
		public DateTime SuggestedCompletedBy { get; private set; }
		public Summary Summary { get; }
		public HashSet<Step> Steps { get; }
		public long Price { get; private set; }
		public long SuggestedPrice { get; private set; }
		
		public IEnumerable<string> KeywordsAsString => Keywords.OrderedTaxonomy;

		public static Expectations Of(Summary summary, Description description, Keywords keywords, DateTime completedBy, HashSet<Step> steps, long price)
			=> new Expectations(summary, description, keywords, completedBy, steps, price);

		public Expectations WithAdjusted(DateTime suggestedCompletedBy)
			=> new Expectations(Summary, Description, Keywords, CompletedBy, suggestedCompletedBy, Steps, Price, SuggestedPrice);

		public Expectations WithAdjusted(long suggestedPrice) 
			=> new Expectations(Summary, Description, Keywords, CompletedBy, SuggestedCompletedBy, Steps, Price, suggestedPrice);

		public Expectations WithNew(Summary summary) 
			=> new Expectations(summary, Description, Keywords, CompletedBy, SuggestedCompletedBy, Steps, Price, SuggestedPrice);

		public Expectations WithNew(Description description) 
			=> new Expectations(Summary, description, Keywords, CompletedBy, SuggestedCompletedBy, Steps, Price, SuggestedPrice);

		public Expectations WithNew(Step step)
		{
			var newSteps = new HashSet<Step>();
			newSteps.Add(step);
			newSteps.UnionWith(Steps);
			return new Expectations(Summary, Description, Keywords, CompletedBy, SuggestedCompletedBy, newSteps, Price, SuggestedPrice);
		}

  		public Expectations WithRefined(Keywords keywords) 
	        => new Expectations(Summary, Description, keywords, CompletedBy, SuggestedCompletedBy, Steps, Price, SuggestedPrice);

        public override int GetHashCode()
		{
			return Summary.GetHashCode() + Description.GetHashCode() + CompletedBy.GetHashCode() + Steps.GetHashCode();
		}

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Expectations))
			{
				return false;
			}

			var otherExpectations = (Expectations)other;

			return Summary.Equals(otherExpectations.Summary)
					&& Description.Equals(otherExpectations.Description)
                    && Keywords.Equals(otherExpectations.Keywords)
                    && CompletedBy.Equals(otherExpectations.CompletedBy)
                    && SuggestedCompletedBy.Equals(SuggestedCompletedBy)
                    && Steps.Equals(otherExpectations.Steps)
                    && Price == otherExpectations.Price
                    && SuggestedPrice == otherExpectations.SuggestedPrice;
        }

        public override string ToString() =>
	        "Expectations[summary=" + Summary
	                                + " Description=" + Description
	                                + " CompletedBy=" + CompletedBy
	                                + " SuggestedCompletedBy=" + SuggestedCompletedBy
	                                + " Steps=" + Steps
	                                + " Price=" + Price
	                                + " SuggestedPrice=" + SuggestedPrice
	                                + "]";

        internal static string[] ConvertFromKeywords(Keywords keywords)
        {
	        if (keywords != null) return keywords.OrderedTaxonomy.ToArray();
	        return Array.Empty<string>();
        }

        internal static string[] ConvertFromSteps(HashSet<Step> steps)
		{
			if (steps != null)
			{
				var plainSteps = new string[steps.Count];
				var idx = 0;
				foreach (var step in steps)
				{
					plainSteps[idx] = $"{step.Sequence}={step.Description}";
				}

				return plainSteps;
			}

			return Array.Empty<string>();
		}

		internal static Keywords ConvertToKeywords(string[] keywords) => Keywords.Are(keywords);

		internal static HashSet<Step> ConvertToSteps(string[] plainSteps)
		{
			var steps = new HashSet<Step>();
            if (plainSteps == null)
            {
                return steps;
            }

			foreach (var plainStep in plainSteps)
			{
				var parts = plainStep.Split("=");
				steps.Add(Step.Ordered(int.Parse(parts[0]), Description.Has(parts[1])));
			}

			return steps;
		}

		private Expectations(Summary summary, Description description, Keywords keywords, DateTime completedBy, HashSet<Step> steps, long price)
		{
			Summary = summary;
			Description = description;
			Keywords = keywords;
			CompletedBy = completedBy;
			SuggestedCompletedBy = completedBy;
			Steps = steps;
			Price = price;
			SuggestedPrice = price;
		}

		private Expectations(Summary summary, Description description, Keywords keywords, DateTime completedBy, DateTime suggestedCompletedBy, HashSet<Step> steps, long price, long suggestedPrice)
		{
			Summary = summary;
			Description = description;
			Keywords = keywords;
			CompletedBy = completedBy;
			SuggestedCompletedBy = completedBy;
			Steps = steps;
			Price = price;
			SuggestedPrice = suggestedPrice;
		}
	}
}
