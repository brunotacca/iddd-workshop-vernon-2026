using VaughnVernon.Mockroservices;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class ProposalPreviouslyMatched : DomainEvent
    {
        public ProposalPreviouslyMatched(Proposal proposal, Doer doer)
        {
            ProposalId = proposal.Id.Value;
            Clientid = proposal.Client.Id.Value;
            DoerId = doer.Id.Value;
            Preferred = doer.Preferred;
        }
        
        public string ProposalId { get; }
        
        public string Clientid { get; }
        
        public string DoerId { get; }
        
        public bool Preferred { get; }
    }
}