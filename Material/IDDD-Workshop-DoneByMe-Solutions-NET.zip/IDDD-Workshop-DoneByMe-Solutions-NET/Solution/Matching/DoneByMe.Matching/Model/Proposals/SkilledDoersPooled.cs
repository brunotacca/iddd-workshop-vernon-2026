﻿using System.Collections.Generic;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
	public class SkilledDoersPooled : DomainEvent
	{
		public string ProposalId { get; private set; }
		public IEnumerable<Doer> Doers { get; }

		public SkilledDoersPooled(Id id, IEnumerable<Doer> doers)
		{
			Doers = doers;
			ProposalId = id.Value;
		}
	}
}
