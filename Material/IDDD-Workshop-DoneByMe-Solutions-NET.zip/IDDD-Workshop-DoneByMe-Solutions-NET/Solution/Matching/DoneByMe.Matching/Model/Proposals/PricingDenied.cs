﻿using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class PricingDenied : DomainEvent
    {
		public string ProposalId { get; private set; }
		public string ClientId { get; private set; }
		public long Price { get; private set; }
		public long SuggestedPrice { get; private set; }

        public PricingDenied(
	        Id proposalId,
	        Client client,
	        Expectations expectations,
	        long suggestedPrice)
        {
	        ProposalId = proposalId.Value;
	        ClientId = client?.Id.Value;
	        if (expectations != null) Price = expectations.Price;
	        SuggestedPrice = suggestedPrice;
        }
    }
}
