using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class RecommendDoers : Command
    {
        public string ProcessIdValue { get; }
        public string[] Keywords { get; }
        public string Locality { get; }

        public RecommendDoers(Id processIdValue, string[] keywords, string locality) : base(processIdValue.Value)
        {
            ProcessIdValue = processIdValue;
            Keywords = keywords;
            Locality = locality;
        }
    }
}