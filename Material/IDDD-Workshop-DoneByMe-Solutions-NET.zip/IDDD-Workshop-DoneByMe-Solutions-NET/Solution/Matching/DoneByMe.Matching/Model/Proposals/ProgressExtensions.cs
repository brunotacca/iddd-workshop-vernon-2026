using System.Collections.Generic;

namespace DoneByMe.Matching.Model.Proposals
{
    public static class ProgressExtensions
    {
        public static bool IsAcceptable(this Progress progress)
        {
            return
                WasSubmitted(progress) &&
                WasPricingVerified(progress) &&
                WasSchedulingVerified(progress);
        }

        public static bool IsUnacceptable(this Progress progress)
        {
            return
                WasSubmitted(progress) &&
                WasPricingDenied(progress) || WasSchedulingDenied(progress);
        }

        public static bool WasPricingDenied(this Progress progress) => progress.Specs.Contains(Spec.PricingDenied);

        public static bool WasPricingVerified(this Progress progress) => progress.Specs.Contains(Spec.PricingVerified);

        public static bool WasSchedulingDenied(this Progress progress) => progress.Specs.Contains(Spec.SchedulingDenied);

        public static bool WasSchedulingVerified(this Progress progress) => progress.Specs.Contains(Spec.SchedulingVerified);

        public static bool WasSubmitted(this Progress progress) => progress.Specs.Contains(Spec.Submitted);

        public static Progress DeniedForPricing(this Progress progress) => WithNewSpec(progress, Spec.PricingDenied);

        public static Progress DeniedForScheduling(this Progress progress) => WithNewSpec(progress, Spec.SchedulingDenied);

        public static Progress SubmittedByClient(this Progress progress) => withOnlySpec(progress, Spec.Submitted);

        public static Progress VerifiedForPricing(this Progress progress) => WithNewSpec(progress, Spec.PricingVerified);

        public static Progress VerifiedForScheduling(this Progress progress) => WithNewSpec(progress, Spec.SchedulingVerified);

        private static Progress WithNewSpec(Progress progress, Spec spec)
        {
            var newSpecs = new HashSet<Spec>(progress.Specs);
            newSpecs.Add(spec);
            return new Progress(newSpecs);
        }

        private static Progress withOnlySpec(Progress progress, Spec spec)
        {
            var newSpecs = new HashSet<Spec>();
            newSpecs.Add(spec);
            return new Progress(newSpecs);
        }
    }
}