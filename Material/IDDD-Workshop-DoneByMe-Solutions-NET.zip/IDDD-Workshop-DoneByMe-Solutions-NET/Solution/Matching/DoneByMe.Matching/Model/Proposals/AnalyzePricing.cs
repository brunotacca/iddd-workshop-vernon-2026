using System;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class AnalyzePricing : Command
    {
        public string[] Taxonomy { get; }
        
        public DateTime DueDate { get; }
        
        public long Price { get; }

        public AnalyzePricing(string id, string[] taxonomy, DateTime dueDate, long price) : base(id)
        {
            Taxonomy = taxonomy;
            DueDate = dueDate;
            Price = price;
        }
    }
}