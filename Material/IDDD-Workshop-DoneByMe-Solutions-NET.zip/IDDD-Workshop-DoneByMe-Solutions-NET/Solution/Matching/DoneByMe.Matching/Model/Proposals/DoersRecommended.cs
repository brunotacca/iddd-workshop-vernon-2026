using System.Collections.Generic;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class DoersRecommended : DomainEvent
    {
        public IEnumerable<Doer> Doers { get; }

        public DoersRecommended(IEnumerable<Doer> doers)
        {
            Doers = doers;
        }
    }
}