// Copyright © 2012-2022 VLINGO LABS. All rights reserved.
//
// This Source Code Form is subject to the terms of the
// Mozilla Public License, v. 2.0. If a copy of the MPL
// was not distributed with this file, You can obtain
// one at https://mozilla.org/MPL/2.0/.

using System.Collections.Generic;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals;

public class NotifyAvailableDoers : Command
{
    public string ProposalId { get; }
    public IEnumerable<Doer> Doers { get; }

    public NotifyAvailableDoers(string proposalId, IEnumerable<Doer> doers): base(proposalId)
    {
        ProposalId = proposalId;
        Doers = doers;
    }
}