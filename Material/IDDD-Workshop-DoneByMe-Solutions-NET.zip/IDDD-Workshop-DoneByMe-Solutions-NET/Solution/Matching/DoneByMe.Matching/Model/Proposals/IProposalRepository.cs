﻿namespace DoneByMe.Matching.Model.Proposals
{
    public interface IProposalRepository
    {
		Proposal ProposalOf(Id id);
		void Save(Proposal proposal);
	}
}
