﻿using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class SchedulingVerified : DomainEvent
    {
		public string ProposalId { get; private set; }
		public string ClientId { get; private set; }
		public long CompletionDate { get; private set; }

        public SchedulingVerified(
			Id proposalId,
			Client client,
			Expectations expectations)
        {
	        ProposalId = proposalId.Value;
			ClientId = client.Id.Value;
			CompletionDate = expectations.CompletedBy.Ticks;
		}
	}
}
