﻿using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class UnderpricingHandled : DomainEvent
    {
		public string ProposalId { get; private set; }
		public int ResubmissionCount { get; private set; }
		public long SuggestedPrice { get; private set; }

        public UnderpricingHandled(
	        Id proposalId,
	        int resubmissionCount,
	        long suggestedPrice)
        {
	        ProposalId = proposalId.Value;
	        ResubmissionCount = resubmissionCount;
	        SuggestedPrice = suggestedPrice;
        }
    }
}
