﻿using VaughnVernon.Mockroservices;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class ProposalSubmitted : DomainEvent
    {
		public string ProposalId { get; private set; }
		public string ClientId { get; private set; }
		public string ClientLocality { get; private set; }
		public string Description { get; private set; }
        public string[] Keywords { get; private set; }
		public string Summary { get; private set; }
		public long CompletedBy { get; private set; }
		public string[] Steps { get; private set; }
		public long Price { get; private set; }

        public ProposalSubmitted(
			Id proposalId,
			Client client,
			Expectations expectations)
        {
	        ProposalId = proposalId.Value;
	        ClientId = client?.Id.Value;
	        ClientLocality = client?.Locality;
	        Summary = expectations?.Summary.Text;
	        Description = expectations?.Description.Text;
	        Keywords = Expectations.ConvertFromKeywords(expectations?.Keywords);
	        Steps = Expectations.ConvertFromSteps(expectations?.Steps);
	        if (expectations != null)
	        {
		        CompletedBy = expectations.CompletedBy.Ticks;
		        Price = expectations.Price;
	        }
        }
	}
}
