﻿using System.Collections.Generic;

namespace DoneByMe.Matching.Model.Proposals
{
    public class Step
    {
		public int Sequence { get; }
		public Description Description { get; }

		public static HashSet<Step> CopyAllOf(HashSet<Step> existingTasks)
		{
			var copy = new HashSet<Step>();

			foreach (var each in existingTasks)
			{
				copy.Add(Step.Ordered(each.Sequence, each.Description));
			}

			return copy;
		}

		public static HashSet<Step> From(Dictionary<int, string> expectations)
		{
			var steps = new HashSet<Step>();

			foreach (var sequence in expectations.Keys)
			{
				var text = expectations[sequence];
				steps.Add(Step.Ordered(sequence, Description.Has(text)));
			}

			return steps;
		}

		public static Step Ordered(int sequence, Description description) => new Step(sequence, description);

		public override int GetHashCode() => Sequence + Description.GetHashCode();

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Step))
			{
				return false;
			}
    
			var otherStep = (Step) other;
    
			return Sequence == otherStep.Sequence && Description.Equals(otherStep.Description);
		}

		public override string ToString() => $"Step[Sequence={Sequence} Description={Description}]";

		private Step(int sequence, Description description)
		{
			Sequence = sequence;
			Description = description;
		}
	}
}
