﻿using System;
using System.Collections.Generic;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class Proposal : SourcedEntity<DomainEvent>
    {
	    private IList<Doer> backupDoers = new List<Doer>();
	    
		public Id Id { get; private set; }
		public Client Client { get; private set; }
		public Doer Doer { get; private set; }
		public Expectations Expectations { get; private set; }
		public Progress Progress { get; private set; }

		public bool IsAcceptable => Progress.IsAcceptable;
		
		public void MatchWith(Doer doer)
		{
			if (!Progress.IsAcceptable())
			{
				throw new InvalidOperationException("Must be acceptable");
			}

			if (!Progress.WasMatched)
			{
				Apply(new ProposalMatched(this, doer));
			}
			else if (!doer.Equals(Doer))
			{
				Apply(new ProposalPreviouslyMatched(this, doer));
			}
		}
		
		public void ResubmitFor(Expectations expectations) => Apply(new ProposalResubmitted(Id, Client, expectations));

		public static Proposal SubmitFor(Client client, Expectations expectations) => new(client, expectations);

		public void DenyPricing(long suggestedPrice)
		{
			if (!Progress.WasPricingDenied)
			{
				Apply(new PricingDenied(Id, Client, Expectations, suggestedPrice));
			}
		}
		
		public void HandleUnderpricing(int resubmissionCount, long suggestedPrice)
		{
			if (!Progress.WasPricingDenied)
			{
				Apply(new UnderpricingHandled(Id, resubmissionCount, suggestedPrice));
			}
		}
		
		public void PoolSkilledDoers(IEnumerable<Doer> doers)
		{
			Apply(new SkilledDoersPooled(Id, doers));
		}
		
		public void MergeSkilledDoers(IEnumerable<Doer> doers)
		{
			Apply(new SkilledDoersMerged(Id, doers));
		}

		public void DenyScheduling(DateTime suggestedCompletionDate)
		{
			if (!Progress.WasSchedulingDenied)
			{
				Apply(new SchedulingDenied(Id, Client, Expectations, suggestedCompletionDate.Ticks));
			}
		}

		public void VerifyPricing()
		{
			if (!Progress.WasPricingVerified)
			{
				Apply(new PricingVerified(Id, Client, Expectations));
			}
		}

		public void VerifyScheduling()
		{
			if (!Progress.WasSchedulingVerified)
			{
				Apply(new SchedulingVerified(Id, Client, Expectations));
			}
		}
		
		public void Accept(string doerId)
		{
			Apply(new ProposalAccepted(Id, doerId));
		}
		
		public void RecommendDoers(IEnumerable<Doer> doers)
		{
			if (!Progress.DoersRecommended)
			{
				Apply(new DoersRecommended(doers));
			}
		}
		
		public void AvailableDoers(IEnumerable<Doer> availableDoers)
		{
			if (!Progress.DoersAvailable)
			{
				//Apply(new DoersAvailabilityChecked());
			}
		}

		public override int GetHashCode() => Id.GetHashCode();

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Proposal))
			{
				return false;
			}
    
			var otherProposal = (Proposal) other;
    
			return Id.Equals(otherProposal.Id);
		}

		public override string ToString()
		{
			return "Proposal[Id=" + Id +
				" Client=" + Client +
				" Expectations=" + Expectations +
				" Progress=" + Progress + "]";
		}
		
		public void When(ProposalMatched proposalMatched) {
			Doer = Doer.From(proposalMatched.DoerId, proposalMatched.Preferred);
			Progress = Progress.Matched();
		}

		public void When(ProposalSubmitted proposalSubmitted)
		{
			Id = Id.FromExisting(proposalSubmitted.ProposalId);
			Client = Client.From(proposalSubmitted.ClientId, proposalSubmitted.ClientLocality);
			Expectations =
                Expectations.Of(
					Summary.Has(proposalSubmitted.Summary),
					Description.Has(proposalSubmitted.Description),
					Expectations.ConvertToKeywords(proposalSubmitted.Keywords),
					new DateTime(proposalSubmitted.CompletedBy),
					Expectations.ConvertToSteps(proposalSubmitted.Steps),
					proposalSubmitted.Price);
			Progress = Progress.Submitted;
		}
		
		public void When(ProposalResubmitted proposalResubmitted)
		{
			Id = Id.FromExisting(proposalResubmitted.ProposalId);
			Client = Client.From(proposalResubmitted.ClientId, proposalResubmitted.ClientLocality);
			Expectations =
				Expectations.Of(
					Summary.Has(proposalResubmitted.Summary),
					Description.Has(proposalResubmitted.Description),
					Expectations.ConvertToKeywords(proposalResubmitted.Keywords),
					new DateTime(proposalResubmitted.CompletedBy),
					Expectations.ConvertToSteps(proposalResubmitted.Steps),
					proposalResubmitted.Price);
			Progress = Progress.Submitted;
		}

        public void When(PricingDenied pricingDenied)
		{
			Expectations = Expectations.WithAdjusted(pricingDenied.SuggestedPrice);
			Progress = Progress.DeniedForPricing();
		}
        
        public void When(UnderpricingHandled underpricingHandled)
        {
	        // TODO: implement logic for underpricing
        }
        
        public void When(SkilledDoersPooled skilledDoersPooled)
        {
	        // TODO: implement logic for doers. Should it go to backupDoers?
        }
        
        public void When(SkilledDoersMerged skilledDoersMerged)
        {
	        // TODO: implement logic for doers. Should it go to backupDoers?
        }
        
        public void When(ProposalAccepted proposalAccepted)
        {
	        // TODO: implement logic for doers. Should it go to backupDoers?
        }

        public void When(PricingVerified pricingVerified) => Progress = Progress.VerifiedForPricing();

        public void When(SchedulingDenied schedulingDenied)
		{
			Expectations = Expectations.WithAdjusted(schedulingDenied.SuggestedCompletionDate);
			Progress = Progress.DeniedForScheduling();
		}

        public void When(SchedulingVerified schedulingVerified) => Progress = Progress.VerifiedForScheduling();

        private Proposal(Client client, Expectations expectations)
			: this(Id.Unique(), client, expectations, Progress.None)
		{
		}

		private Proposal(Id id, Client client, Expectations expectations, Progress progress)
		{
			Apply(new ProposalSubmitted(id, client, expectations));
		}

		public Proposal(IEnumerable<DomainEvent> stream, int streamVersion)
			: base(stream, streamVersion)
		{
		}
    }
}
