// Copyright © 2012-2022 VLINGO LABS. All rights reserved.
//
// This Source Code Form is subject to the terms of the
// Mozilla Public License, v. 2.0. If a copy of the MPL
// was not distributed with this file, You can obtain
// one at https://mozilla.org/MPL/2.0/.

using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals;

public class ProposalAccepted : DomainEvent
{
    public Id Id { get; }
    public string DoerId { get; }

    public ProposalAccepted(Id id, string doerId)
    {
        Id = id;
        DoerId = doerId;
    }
}