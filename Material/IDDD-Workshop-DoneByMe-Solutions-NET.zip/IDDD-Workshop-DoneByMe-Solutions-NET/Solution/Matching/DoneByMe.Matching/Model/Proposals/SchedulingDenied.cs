﻿using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Matching.Model.Proposals
{
    public class SchedulingDenied : DomainEvent
    {
		public string ProposalId { get; private set; }
		public string ClientId { get; private set; }
		public long CompletionDate { get; private set; }
		public long SuggestedCompletionDate { get; private set; }

        public SchedulingDenied(
			Id proposalId,
			Client client,
			Expectations expectations,
			long suggestedCompletionDate)
        {
	        ProposalId = proposalId.Value;
	        ClientId = client.Id.Value;
	        CompletionDate = expectations.CompletedBy.Ticks;
	        SuggestedCompletionDate = suggestedCompletionDate;
        }
	}
}
