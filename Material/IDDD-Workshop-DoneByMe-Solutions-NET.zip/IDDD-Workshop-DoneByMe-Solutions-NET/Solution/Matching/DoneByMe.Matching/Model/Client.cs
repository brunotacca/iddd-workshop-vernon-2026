﻿namespace DoneByMe.Matching.Model
{
    public class Client
    {
		public readonly Id Id;
		public readonly string Locality;

		public static Client From(string referencedId, string locality) => new Client(Id.FromExisting(referencedId), locality);

		public override int GetHashCode() => Id.GetHashCode();

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Client))
			{
				return false;
			}
    
			return Id.Equals(((Client) other).Id);
		}

		public override string ToString() => $"Client[Id={Id}]";

		private Client(Id id, string locality)
		{
			Id = id;
			Locality = locality;
		}
    }
}
