﻿namespace DoneByMe.Matching.Model
{
    public class Description
    {
		public string Text { get; }
  
		public static Description Has(string text) => new Description(text);

		public override int GetHashCode() => Text.GetHashCode();

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Summary))
			{
				return false;
			}
    
			return Text.Equals(((Summary) other).Text);
		}

		public override string ToString() => $"Summary[Text={Text}]";

		private Description(string text) => Text = text;
    }
}
