using System.Collections.Generic;

namespace DoneByMe.Matching.Model
{
    public class Keywords
    {
        private Keywords(params string[] keywords) => OrderedTaxonomy = new List<string>(keywords);

        private Keywords(List<string> keywords) => OrderedTaxonomy = keywords;

        public List<string> OrderedTaxonomy { get; }

        public static Keywords Are(params string[] keywords) => new Keywords(keywords);

        public static Keywords Are(List<string> keywords) => new Keywords(keywords);

        public override bool Equals(object other)
        {
            if (other == null || other.GetType() != GetType()) return false;
            return OrderedTaxonomy.Equals(((Keywords) other).OrderedTaxonomy);
        }

        public override int GetHashCode() => 31 * OrderedTaxonomy.GetHashCode();
    }
}