﻿using System;
using System.Collections.Generic;
using DoneByMe.Matching.Model;
using DoneByMe.Matching.Model.Proposals;

namespace DoneByMe.Matching.Application
{
    public class ProposalCommands
    {
		private readonly IProposalRepository repository;
  
		public ProposalCommands(IProposalRepository repository) => this.repository = repository;

		public void Match(string proposalId, string doerId, bool preferred)
		{
			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.MatchWith(Doer.From(doerId, preferred));
			repository.Save(proposal);
		}

		// public void AcceptPricing(string proposalId)
		// {
		// 	var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
		// 	proposal.(suggestedPrice);
		// 	repository.Save(proposal);
		// }
		
		public void DenyPricing(
			string proposalId,
			long suggestedPrice)
		{

			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.DenyPricing(suggestedPrice);
			repository.Save(proposal);
		}

		public void DenyScheduling(
			string proposalId,
			DateTime suggestedCompletionDate)
		{

			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.DenyScheduling(suggestedCompletionDate);
			repository.Save(proposal);
		}

		public void SubmitProposal(
			string clientId,
			string clientLocality,
			string summary,
			List<string> keywords,
			string description,
			DateTime completedBy,
			Dictionary<int, string> steps,
			long price)
		{

			var proposal =
				Proposal.SubmitFor(
					Client.From(clientId, clientLocality),
					Expectations.Of(
						Summary.Has(summary),
						Description.Has(description),
						Keywords.Are(keywords),
						completedBy,
						Step.From(steps),
						price));

			repository.Save(proposal);
		}

		public void VerifyPricing(string proposalId)
		{
			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.VerifyPricing();
			repository.Save(proposal);
		}

		public void VerifyScheduling(string proposalId)
		{
			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.VerifyScheduling();
			repository.Save(proposal);
		}

		public void HandleUnderpriced(string proposalId, int resubmissionCount, long suggestedPrice)
		{
			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.HandleUnderpricing(resubmissionCount, suggestedPrice);
			repository.Save(proposal);
		}

		public void PoolSkilledDoers(string proposalId, IEnumerable<Doer> doers)
		{
			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.PoolSkilledDoers(doers);
			repository.Save(proposal);
		}

		public void MergeSkilledDoers(string proposalId, IEnumerable<Doer> doers)
		{
			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.MergeSkilledDoers(doers);
			repository.Save(proposal);
		}
		
		public void Accept(string proposalId, string doerId)
		{
			var proposal = repository.ProposalOf(Id.FromExisting(proposalId));
			proposal.Accept(doerId);
			repository.Save(proposal);
		}
    }
}
