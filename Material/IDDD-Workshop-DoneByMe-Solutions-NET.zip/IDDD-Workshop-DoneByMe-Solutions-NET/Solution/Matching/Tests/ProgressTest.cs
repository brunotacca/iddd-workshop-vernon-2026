using DoneByMe.Matching.Model.Proposals;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
    public class ProgressTest
    {
        [TestMethod]
        public void TestObjectProgression()
        {
            var acceptable =
                Progress.Submitted
                    .VerifiedForPricing()
                    .VerifiedForScheduling();

            Assert.IsTrue(acceptable.IsAcceptable);
        }

        [TestMethod]
        public void TestFunctionProgression()
        {
            var progress = Progress.Submitted;

            var submittedVerifiedPricingScheduling =
                progress.SubmittedByClient().VerifiedForPricing().VerifiedForScheduling();

            Assert.IsTrue(submittedVerifiedPricingScheduling.IsAcceptable());
        }

        [TestMethod]
        public void TestComposedFunctionProgression()
        {
            var progress = Progress.Submitted;

            var acceptable =
                ProgressExtensions.VerifiedForScheduling(
                    ProgressExtensions.VerifiedForPricing(
                        ProgressExtensions.SubmittedByClient(progress)));

            Assert.IsTrue(acceptable.IsAcceptable());
        }
    }
}