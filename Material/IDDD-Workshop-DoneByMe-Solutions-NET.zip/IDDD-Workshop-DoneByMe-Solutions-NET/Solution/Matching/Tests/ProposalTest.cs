using System;
using System.Collections.Generic;
using DoneByMe.Matching.Model;
using DoneByMe.Matching.Model.Proposals;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
    public class ProposalTest
    {
        [TestMethod]
        public void TestThatProposalMatchesWithDoer()
        {
            // given
            var proposal = Proposal.SubmitFor(Client(), Expectations());
            proposal.VerifyPricing();
            proposal.VerifyScheduling();
            Assert.IsTrue(proposal.IsAcceptable);
            proposal.Applied.Clear();

            // when
            proposal.MatchWith(Doer());

            // then
            Assert.AreEqual(1, proposal.Applied.Count);
            Assert.IsInstanceOfType(proposal.Applied[0], typeof(ProposalMatched));
            Assert.AreEqual(Client(), proposal.Client);
            Assert.AreEqual(Doer(), proposal.Doer);
            Assert.IsTrue(proposal.Progress.WasMatched);
        }

        private Client Client()
        {
            return DoneByMe.Matching.Model.Client.From("12345", "Washington D.C.");
        }

        private Doer Doer()
        {
            return DoneByMe.Matching.Model.Doer.PreferredFrom("ABC");
        }

        private Expectations Expectations()
        {
            return
                DoneByMe.Matching.Model.Proposals.Expectations.Of(
                    Summary.Has("I need my windows washed by the best."),
                    Description.Has("When I say 'jump,' you ask 'how high?'"),
                    Keywords.Are("#windows", "#washing", "#indoor", "#outdoor", "#extra-tall"),
                    new DateTime(DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() + 24 * 60 * 60 * 1000),
                    new HashSet<Step>(new []{ Step.Ordered(1, Description.Has("Step 1")) }), 
                    1995);
        }
    }
}