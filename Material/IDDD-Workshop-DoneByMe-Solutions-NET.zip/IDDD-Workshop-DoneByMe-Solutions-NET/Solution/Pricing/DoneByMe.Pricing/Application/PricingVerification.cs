﻿// Application Service

using DoneByMe.Pricing.Model;

namespace DoneByMe.Pricing.Application
{
	using Model.Analysis;
    using System;

    public class PricingVerification
    {
		private readonly PricingAnalyzer pricingAnalyzer = new PricingAnalyzer();

		public void VerifyPricing(string pricedItemId, string[] taxonomy, DateTime dueDate, long price) 
			=> pricingAnalyzer.AnalyzePricing(pricedItemId, PricingClassification.Is(taxonomy), dueDate, price);

		public void VerifyAdjustedPricing(string pricedItemId, string[] taxonomy, DateTime dueDate, long price) 
			=> pricingAnalyzer.AnalyzeAdjustedPricing(pricedItemId, PricingClassification.Is(taxonomy), dueDate, price);
    }
}
