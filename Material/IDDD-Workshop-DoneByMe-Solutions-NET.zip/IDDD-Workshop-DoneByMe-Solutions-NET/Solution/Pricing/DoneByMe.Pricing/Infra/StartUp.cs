﻿namespace DoneByMe.Pricing.Infra
{
	using Messaging;
	using Persistence;
	using Model.Analysis;

    public class StartUp
    {
			public static void Start()
			{
				PricingJournal.Start();
				PricingJournalPublisher.Start();
				AllTopicSubscriber.Start();
				PricingAnalyzer.Start(Repositories.PricingAnalysisRepository);
			}
    }
}
