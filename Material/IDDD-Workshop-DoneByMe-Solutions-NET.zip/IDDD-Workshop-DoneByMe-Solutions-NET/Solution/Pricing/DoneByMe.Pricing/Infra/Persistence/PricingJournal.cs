﻿using VaughnVernon.Mockroservices;
using VaughnVernon.Mockroservices.Journals;

namespace DoneByMe.Pricing.Infra.Persistence
{
    public class PricingJournal
    {
	    public static Journal EventJournal { get; } = Journal.Open("donebyme-pricing");

		public static void Start() { }

		public static void Stop() => EventJournal.Close();
    }
}
