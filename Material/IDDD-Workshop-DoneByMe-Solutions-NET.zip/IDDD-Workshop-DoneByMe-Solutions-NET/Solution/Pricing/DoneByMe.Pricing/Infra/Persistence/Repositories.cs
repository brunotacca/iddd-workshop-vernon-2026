﻿namespace DoneByMe.Pricing.Infra.Persistence
{
	using Model.Analysis;

	public class Repositories
    {
		private static IPricingAnalysisRepository pricingAnalysisRepository;
		public static IPricingAnalysisRepository PricingAnalysisRepository
        {
			get
			{
				if (pricingAnalysisRepository == null)
				{
                    pricingAnalysisRepository = new JournalPricingAnalysisRepository();
				}
				return pricingAnalysisRepository;
			}
		}
	}
}
