﻿using VaughnVernon.Mockroservices.Journals;
using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Pricing.Infra.Persistence
{
	using Model;
	using Model.Analysis;

    public class JournalPricingAnalysisRepository : Repository, IPricingAnalysisRepository
	{
		private readonly Journal journal;
		private readonly EntryStreamReader reader;

		public PricingAnalysis PricingAnalysisOf(Id id)
		{
			var stream = reader.StreamFor(id.Value);

			return new PricingAnalysis(ToSourceStream<DomainEvent>(stream.Stream), stream.StreamVersion);
		}

		public void Save(PricingAnalysis pricingAnalysis) 
			=> journal.Write(pricingAnalysis.Id.Value, pricingAnalysis.NextVersion, ToBatch(pricingAnalysis.Applied));

		internal JournalPricingAnalysisRepository()
		{
            journal = PricingJournal.EventJournal;
            reader = journal.StreamReader();
		}
	}
}
