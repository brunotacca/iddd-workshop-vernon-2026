﻿using VaughnVernon.Mockroservices.Exchanges;
using VaughnVernon.Mockroservices.MessageBuses;

namespace DoneByMe.Pricing.Infra.Messaging
{
	using VaughnVernon.Mockroservices;
	using Infra;

    public class AllTopicSubscriber : ISubscriber
	{
		private static AllTopicSubscriber instance;

		public static AllTopicSubscriber Start()
		{
			if (instance == null)
			{
				instance = new AllTopicSubscriber();
			}
			return instance;
		}

		public void Handle(Message message)
		{
            var reader = MessageExchangeReader.From(message);
            switch (message.SimpleTypeName())
            {
                case "DoneByMe.Matching.Model.Proposals.ProposalSubmitted":
                    API.PricingVerification.VerifyPricing(
                        reader.PayloadStringValue("proposalId"),
                        reader.PayloadStringArrayValue("keywords"),
                        reader.PayloadDateTimeValue("completedBy"),
                        reader.PayloadLongValue("price"));
                    break;
                case "DoneByMe.Matching.Model.Proposals.ProposalResubmitted":
                    API.PricingVerification.VerifyAdjustedPricing(
                        reader.PayloadStringValue("proposalId"),
                        reader.PayloadStringArrayValue("keywords"),
                        reader.PayloadDateTimeValue("completedBy"),
                        reader.PayloadLongValue("price"));
                    break;
            }
        }

		private AllTopicSubscriber()
		{
			var messageBus = MessageBus.Start("donebyme");
			var allTopic = messageBus.OpenTopic("all");

			allTopic.Subscribe(this);
		}
	}
}
