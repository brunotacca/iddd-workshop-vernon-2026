﻿using DoneByMe.Pricing.Infra.Persistence;
using VaughnVernon.Mockroservices.Journals;
using VaughnVernon.Mockroservices.MessageBuses;

namespace DoneByMe.Pricing.Infra.Messaging
{
    public class PricingJournalPublisher
    {
		private static JournalPublisher journalPublisher;

		public static void Start()
		{
			var messageBus = MessageBus.Start("donebyme");
			var topic = messageBus.OpenTopic("all");

			journalPublisher =
				JournalPublisher.From(
					PricingJournal.EventJournal.Name,
					messageBus.Name,
					topic.Name);
		}

		public static void Stop()
		{
			journalPublisher.Close();
		}
    }
}
