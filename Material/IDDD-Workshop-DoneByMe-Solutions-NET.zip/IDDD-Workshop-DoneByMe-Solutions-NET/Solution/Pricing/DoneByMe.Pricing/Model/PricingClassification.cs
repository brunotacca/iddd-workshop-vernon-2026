using System.Collections.Generic;
using System.Linq;

namespace DoneByMe.Pricing.Model
{
    public class PricingClassification
    {
        public IEnumerable<string> Taxonomy { get; }

        public static PricingClassification Is(params string[] taxonomy) => new PricingClassification(taxonomy);

        public static PricingClassification Is(List<string> taxonomy) => new PricingClassification(taxonomy);

        public string[] Flattened()
        {
            return Taxonomy.ToArray();
        }

        public override bool Equals(object other)
        {
            if (other == null || other.GetType() != GetType())
            {
                return false;
            }
            return Taxonomy.Equals(((PricingClassification)other).Taxonomy);
        }

        public override int GetHashCode() => 31 * Taxonomy.GetHashCode();

        private PricingClassification(params string[] taxonomy) => Taxonomy = new List<string>(taxonomy);

        public PricingClassification(List<string> taxonomy) => Taxonomy = taxonomy;
    }
}
