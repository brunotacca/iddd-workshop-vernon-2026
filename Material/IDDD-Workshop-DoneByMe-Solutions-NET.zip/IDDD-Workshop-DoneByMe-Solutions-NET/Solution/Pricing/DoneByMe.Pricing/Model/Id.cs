﻿using System;

namespace DoneByMe.Pricing.Model
{
	public class Id
    {
		public static Id FromExisting(string referencedId) => new Id(referencedId);

		public static Id Unique() => new Id();

		public string Value { get; }

		public override int GetHashCode() => Value.GetHashCode();

		public override bool Equals(object other)
		{
			if (other == null || other.GetType() != typeof(Id))
			{
				return false;
			}
    
			var otherId = (Id) other;
    
			return Value.Equals(otherId.Value);
		}

		public override string ToString() => $"Id[Value={Value}]";

		private Id() => Value = Guid.NewGuid().ToString();

		private Id(string referencedId) => Value = referencedId;
    }
}
