﻿// Domain Service
namespace DoneByMe.Pricing.Model.Analysis
{
	using System;

    public class PricingAnalyzer
    {
		private static IPricingAnalysisRepository repository;

		public static void Start(IPricingAnalysisRepository repository)
		{
			PricingAnalyzer.repository = repository;
		}

        public void AnalyzeAdjustedPricing(string pricedItemId, PricingClassification pricingClassification, DateTime dueDate, long price)
        {
            var pricingAnalysis = repository.PricingAnalysisOf(Id.FromExisting(pricedItemId));
            // pricingAnalysis.VerifyPricing(pricingClassification, price);
        }

		public void AnalyzePricing(string pricedItemId, PricingClassification pricingClassification, DateTime dueDate, long price)
		{
            var verified = (Guid.NewGuid().GetHashCode() % 2) == 0;
            Console.WriteLine("V: " + verified);
            PricingAnalysis pricingAnalysis;

			if (verified)
			{
				pricingAnalysis = PricingAnalysis.VerifyWith(pricedItemId, pricingClassification, dueDate, price);
			}
			else
			{
				pricingAnalysis = PricingAnalysis.RejectWith(pricedItemId, pricingClassification, dueDate, price, price * 2);
			}

			Console.WriteLine("#1 PricingAnalyzer completed with: " + (verified ? "verified" : "rejected"));

			repository.Save(pricingAnalysis);
		}
    }
}
