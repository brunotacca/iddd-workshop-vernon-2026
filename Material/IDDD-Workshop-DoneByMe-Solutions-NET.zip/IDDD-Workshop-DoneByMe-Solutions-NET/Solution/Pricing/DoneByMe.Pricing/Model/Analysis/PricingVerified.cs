using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Pricing.Model.Analysis
{
    using System;

    public class PricingVerified : DomainEvent
    {
        public string OriginatorId { get; private set; }
        public string[] Taxonomy { get; private set; }
        public long DueDate { get; private set; }
        public long Price { get; private set; }

        public PricingVerified(string originatorId, PricingClassification pricingClassification, DateTime dueDate, long price)
        {
            OriginatorId = originatorId;
            Taxonomy = pricingClassification.Flattened();
            DueDate = dueDate.Ticks;
            Price = price;
        }
    }
}
