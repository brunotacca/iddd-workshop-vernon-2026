﻿using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Pricing.Model.Analysis
{
    using System;
    using System.Collections.Generic;
    using VaughnVernon.Mockroservices;

    public class PricingAnalysis : SourcedEntity<DomainEvent>
    {
        public Id Id { get; private set; }
        private DateTime DueDate { get; set; }
        private long Price { get; set; }
        private PricingClassification PricingClassification { get; set; }
        private long SuggestedPrice { get; set; }
        // private HashSet<PriceHistory> PriceHistory

        public static PricingAnalysis VerifyWith(
                string pricedItemId,
                PricingClassification pricingClassification,
                DateTime dueDate,
                long price)
        {
            return new PricingAnalysis(Id.FromExisting(pricedItemId), pricingClassification, dueDate, price);
        }

        public static PricingAnalysis RejectWith(
                string pricedItemId,
                PricingClassification pricingClassification,
                DateTime dueDate,
                long price,
                long suggestedPrice)
        {
            return new PricingAnalysis(Id.FromExisting(pricedItemId), pricingClassification, dueDate, price, suggestedPrice);
        }

        public void When(PricingVerified e)
        {
            Id = Id.FromExisting(e.OriginatorId);
            PricingClassification = PricingClassification.Is(e.Taxonomy);
            Price = e.Price;
            SuggestedPrice = e.Price;
        }

        public void When(PricingRejected e)
        {
            Id = Id.FromExisting(e.OriginatorId);
            PricingClassification = PricingClassification.Is(e.Taxonomy);
            Price = e.Price;
            SuggestedPrice = e.SuggestedPrice;
        }

        public PricingAnalysis(IEnumerable<DomainEvent> events, int streamVersion)
            : base(events, streamVersion)
        {
        }

        private PricingAnalysis(Id id, PricingClassification pricingClassification, DateTime dueDate, long price) 
            => Apply(new PricingVerified(id.Value, pricingClassification, dueDate, price));

        private PricingAnalysis(Id id, PricingClassification pricingClassification, DateTime dueDate, long price, long suggestedPrice) 
            => Apply(new PricingRejected(id.Value, pricingClassification, dueDate, price, suggestedPrice));
    }
}
