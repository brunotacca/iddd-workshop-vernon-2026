using VaughnVernon.Mockroservices.Model;

namespace DoneByMe.Pricing.Model.Analysis
{
    using System;

    public class PricingRejected : DomainEvent
    {
        public string OriginatorId { get; private set; }
        public string[] Taxonomy { get; private set; }
        public long DueDate { get; private set; }
        public long Price { get; private set; }
        public long SuggestedPrice { get; private set; }

        public PricingRejected(string originatorId, PricingClassification pricingClassification, DateTime dueDate, long price, long suggestedPrice)
        {
            OriginatorId = originatorId;
            Taxonomy = pricingClassification.Flattened();
            DueDate = dueDate.Ticks;
            Price = price;
            SuggestedPrice = suggestedPrice;
        }
    }
}
