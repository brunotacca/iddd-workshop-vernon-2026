﻿namespace DoneByMe.Bootstrap
{
    class Bootstrap
    {
        static void Main(string[] args)
        {
			Matching.Infra.StartUp.Start();
			Pricing.Infra.StartUp.Start();
        }
    }
}
