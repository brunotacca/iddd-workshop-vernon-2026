package co.donebyme.matching.model.proposal;

import java.util.Date;
import java.util.List;

import co.donebyme.matching.model.Client;
import co.donebyme.matching.model.Description;
import co.donebyme.matching.model.Doer;
import co.donebyme.matching.model.Id;
import co.donebyme.matching.model.Summary;
import co.vaughnvernon.mockroservices.model.DomainEvent;
import co.vaughnvernon.mockroservices.model.SourcedEntity;

public class Proposal extends SourcedEntity<DomainEvent> {
  private ProposalState state;

  public static Proposal submitFor(final Client client, final Expectations expectations) {
    return new Proposal(client, expectations);
  }

  public boolean isAcceptable() {
    return state.progress.isAcceptable();
  }
  
  public Id id() {
    return state.id;
  }

  public void resubmitFor(final Expectations expectations) {
    apply(new ProposalResubmitted(state.id, state.client, expectations));
  }

  public void acceptBy(Doer doer) {
	if (!state.progress.wasMatched()) {
	  apply(new ProposalAccepted(state.id, state.client, doer));
	} else {
	  apply(new ProposalPreviouslyAccepted(state.id, state.client, doer));
	}
  }

  public void denyPricing(final long suggestedPrice) {
    if (!state.progress.wasPricingDenied()) {
      apply(new PricingDenied(state.id, state.client, state.expectations, suggestedPrice));
    }
  }
  
  public void denyScheduling(final Date suggestedCompletionDate) {
    if (!state.progress.wasSchedulingDenied()) {
      apply(new SchedulingDenied(state.id, state.client, state.expectations, suggestedCompletionDate));
    }
  }
  
  public void verifyPricing() {
    if (!state.progress.wasPricingVerified()) {
      apply(new PricingVerified(state.id, state.client, state.expectations));
    }
  }
  
  public void verifyScheduling() {
    if (!state.progress.wasSchedulingVerified()) {
      apply(new SchedulingVerified(state.id, state.client, state.expectations));
    }
  }
  
  @Override
  public int hashCode() {
    return state.id.hashCode();
  }

  @Override
  public boolean equals(final Object other) {
    if (other == null || other.getClass() != Proposal.class) {
      return false;
    }
    
    final Proposal otherProposal = (Proposal) other;
    
    return this.state.id.equals(otherProposal.state.id);
  }

  @Override
  public String toString() {
    return "Proposal[id=" + state.id +
        " client=" + state.client +
        " expectations=" + state.expectations +
        " progress=" + state.progress + "]";
  }

  protected void when(final ProposalSubmitted event) {
	this.state = ProposalState.with(Id.fromExisting(
			event.proposalId),
			Client.from(event.clientId),
			Expectations.of(
		            Summary.has(event.summary),
		            Description.has(event.description),
		            Expectations.convertToKeywords(event.keywords),
		            new Date(event.completedBy),
		            Expectations.convertToSteps(event.steps),
		            event.price),
			Progress.Submitted);
  }

  protected void when(final ProposalResubmitted event) {
    this.state = state.withDifferent(
            Expectations.of(
                Summary.has(event.summary),
                Description.has(event.description),
                Expectations.convertToKeywords(event.keywords),
                new Date(event.completedBy),
                Expectations.convertToSteps(event.steps),
                event.price));
  }

  protected void when(final ProposalAccepted event) {
	this.state = state
		  .withMatched(event.doer)
		  .withAdvanced(state.progress.matched());
  }

  protected void when(final ProposalPreviouslyAccepted event) {
	this.state = state.withBackup(event.doer);
  }

  protected void when(final PricingDenied event) {
	this.state = state
			.withDifferent(state.expectations.withAdjusted(event.suggestedPrice))
			.withAdvanced(state.progress.deniedForPricing());
  }

  protected void when(final PricingVerified event) {
    this.state = state.withAdvanced(state.progress.verifiedForPricing());
  }
  
  protected void when(final SchedulingDenied event) {
	this.state = state
			.withDifferent(state.expectations.withAdjusted(event.suggestedCompletionDate))
			.withAdvanced(state.progress.deniedForScheduling());
  }
  
  protected void when(final SchedulingVerified event) {
    this.state = state.withAdvanced(state.progress.verifiedForScheduling());
  }

  Client client() { return state.client; }
  Progress progress() { return state.progress; }

  private Proposal(final Client client, final Expectations expectations) {
    this(Id.unique(), client, expectations, Progress.None);
  }
  
  private Proposal(final Id id, final Client client, final Expectations expectations, final Progress progress) {
    apply(new ProposalSubmitted(id, client, expectations));
  }

  /**
   * INTERNAL USE ONLY.
   * @param stream the List<DomainEvent> stream of events
   * @param streamVersion the long version of this proposal
   */
  public Proposal(final List<DomainEvent> stream, final long streamVersion) {
    super(stream, (int) streamVersion);
  }
}
