package co.donebyme.matching.resources;

public class ProposalData {
  public final String clientId;
  public final String expectations;
  
  public ProposalData(final String clientId, final String expectations) {
    this.clientId = clientId;
    this.expectations = expectations;
  }
}
