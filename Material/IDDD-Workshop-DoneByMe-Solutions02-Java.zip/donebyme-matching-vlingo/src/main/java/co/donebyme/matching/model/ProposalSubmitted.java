package co.donebyme.matching.model;

import io.vlingo.lattice.model.DomainEvent;

public class ProposalSubmitted extends DomainEvent {
  public final String proposalId;
  public final String clientId;
  public final String expectations;
  
  public ProposalSubmitted(final String proposalId, final String clientId, final String expectations) {
    this.proposalId = proposalId;
    this.clientId = clientId;
    this.expectations = expectations;
  }
}
