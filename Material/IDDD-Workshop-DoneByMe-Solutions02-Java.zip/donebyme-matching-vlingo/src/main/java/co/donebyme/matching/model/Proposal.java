package co.donebyme.matching.model;

import java.util.UUID;

import io.vlingo.actors.Stage;
import io.vlingo.common.Completes;

public interface Proposal {
  public static String submitFor(
          final Stage stage,
          final String clientId,
          final String expectations) {
    String id = UUID.randomUUID().toString();
    
    final Proposal proposal = stage.actorFor(Proposal.class, ProposalEntity.class, id);
    proposal.submitFor(clientId, expectations);    
    return id;
  }

  Completes<String> submitFor(final String clientId, final String expectations);
}
