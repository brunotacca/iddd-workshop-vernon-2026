package co.donebyme.pingpong;

import io.vlingo.actors.World;

public class Application {

  public static void main(String[] args) throws Exception {
    World world = World.startWithDefaults("my-cool-world");
    Ponger ponger = world.actorFor(Ponger.class, PongerActor.class);
    world.actorFor(Pinger.class, PingerActor.class, ponger);

    Thread.sleep(50000);
  }

}
