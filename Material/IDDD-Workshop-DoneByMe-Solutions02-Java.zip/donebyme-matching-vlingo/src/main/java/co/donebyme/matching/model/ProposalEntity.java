package co.donebyme.matching.model;

import io.vlingo.common.Completes;
import io.vlingo.lattice.model.sourcing.EventSourced;
import io.vlingo.lattice.model.sourcing.Sourced;

public class ProposalEntity extends EventSourced implements Proposal {
  private final String id;
  private String clientId;
  private String expectations;
  
  public ProposalEntity(final String id) {
    this.id = id;
  }

  @Override
  public Completes<String> submitFor(final String clientId, final String expectations) {
    apply(new ProposalSubmitted(id, clientId, expectations));
    return completes().with(id);
  }

  @Override
  protected String streamName() {
    return id;
  }

  static {
    Sourced.registerConsumer(ProposalEntity.class, ProposalSubmitted.class, ProposalEntity::whenProposalSubmitted);
  }

  private void whenProposalSubmitted(final ProposalSubmitted event) {
    this.clientId = event.clientId;
    this.expectations = event.expectations;
  }
}
