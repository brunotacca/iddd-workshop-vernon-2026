package co.donebyme.matching.infa.persistence;

import co.donebyme.matching.model.ProposalSubmitted;
import io.vlingo.common.serialization.JsonSerialization;
import io.vlingo.symbio.BaseEntry.TextEntry;
import io.vlingo.symbio.EntryAdapter;
import io.vlingo.symbio.Metadata;

public class EntryAdapters {
  public static final class ProposalSubmittedAdapter implements EntryAdapter<ProposalSubmitted,TextEntry> {
    @Override
    public ProposalSubmitted fromEntry(final TextEntry entry) {
      return JsonSerialization.deserialized(entry.entryData(), ProposalSubmitted.class);
    }

    @Override
    public TextEntry toEntry(final ProposalSubmitted source) {
      return toEntry(source, source.proposalId);
    }

    @Override
    public TextEntry toEntry(final ProposalSubmitted source, final String id) {
      final String serialization = JsonSerialization.serialized(source);
      return new TextEntry(id, ProposalSubmitted.class, 1, serialization, Metadata.nullMetadata());
    }
  }
}
