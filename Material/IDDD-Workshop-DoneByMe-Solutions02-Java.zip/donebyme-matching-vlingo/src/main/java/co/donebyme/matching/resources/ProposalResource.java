package co.donebyme.matching.resources;

import static io.vlingo.http.Response.Status.Created;
import static io.vlingo.http.resource.ResourceBuilder.post;
import static io.vlingo.http.resource.ResourceBuilder.resource;
import static io.vlingo.http.ResponseHeader.*;

import co.donebyme.matching.model.Proposal;
import io.vlingo.actors.Logger;
import io.vlingo.actors.Stage;
import io.vlingo.actors.World;
import io.vlingo.common.Completes;
import io.vlingo.http.Response;
import io.vlingo.http.resource.Resource;
import io.vlingo.http.resource.ResourceHandler;

public class ProposalResource extends ResourceHandler {
  private final Logger logger;
  private final Stage stage;

  public ProposalResource(final World world) {
    this.logger = world.defaultLogger();
    this.stage = world.stage();
  }

  // curl -i -X POST -H "Content-Type: application/json"
  //    -d '{ "clientId":"12345", "expectations":"Window Washing!!!" } ' http://localhost:8081/proposals
  public Completes<Response> submitProposal(ProposalData proposal) {
    logger.info("SUBMIT PROPOSAL: " + proposal.clientId + " EXPECATIONS: " + proposal.expectations);
    
    String proposalId = Proposal.submitFor(stage, proposal.clientId, proposal.expectations);
    
    return Completes.withSuccess(Response.of(Created, headers(of(Location, location(proposalId)))));
  }

  public Resource<?> routes() {
    return resource("Proposal Resource",
            post("/proposals")
              .body(ProposalData.class)
              .handle(this::submitProposal));
  }

  private String location(final String proposalId) {
    return "/proposals/" + proposalId;
  }
}
