package co.donebyme.matching.infa;

import co.donebyme.matching.model.ProposalEntity;
import co.donebyme.matching.resources.ProposalResource;
import io.vlingo.actors.World;
import io.vlingo.http.resource.Configuration.Sizing;
import io.vlingo.http.resource.Configuration.Timing;
import io.vlingo.http.resource.Resources;
import io.vlingo.http.resource.Server;
import io.vlingo.lattice.model.sourcing.SourcedTypeRegistry;
import io.vlingo.symbio.EntryAdapterProvider;
import io.vlingo.symbio.store.journal.NoOpJournalListener;
import io.vlingo.symbio.store.journal.inmemory.InMemoryJournalActor;

public class Bootstrap {
  private static Bootstrap instance;
  
  private final Server server;
  private final World world;
  
  public static void main(String[] args) {
    instance = new Bootstrap();
  }
  
  @SuppressWarnings({ "unchecked", "rawtypes" })
  private Bootstrap() {
    this.world = World.startWithDefaults("donebyme-matching");
    
    final ProposalResource proposalResource = new ProposalResource(world);
    
    final Resources resources = Resources.are(proposalResource.routes());
    
    this.server = Server.startWith(world.stage(), resources, 8081, Sizing.define(), Timing.define());
    
    SourcedTypeRegistry.register(
            world,
            InMemoryJournalActor.class,
            new NoOpJournalListener(),
            ProposalEntity.class);
  }
}
