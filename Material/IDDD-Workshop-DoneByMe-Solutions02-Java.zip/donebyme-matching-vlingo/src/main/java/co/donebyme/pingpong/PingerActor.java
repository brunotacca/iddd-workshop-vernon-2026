package co.donebyme.pingpong;

import io.vlingo.actors.Actor;
import io.vlingo.actors.Stoppable;
import io.vlingo.actors.testkit.TestState;
import io.vlingo.common.Scheduled;
import io.vlingo.common.Cancellable;

public class PingerActor extends Actor implements Pinger, Scheduled<Void> {
  private int pinged;
  private Ponger ponger;
  private Cancellable cancellable;
  private final Pinger self;

  @SuppressWarnings("unchecked")
  public PingerActor(Ponger ponger) {
    this.pinged = 0;
    this.ponger = ponger;
    this.self = selfAs(Pinger.class);
    this.cancellable = this.scheduler().schedule(this.selfAs(Scheduled.class), null, 0L, 1000L);
  }

  @Override
  public void ping() {
    this.pinged++;
    
    logger().info(pinged + " - PING please show the latest update");
    ponger.pong(self);      
  }

  @Override
  public void intervalSignal(Scheduled<Void> scheduled, Void data) {
    if (pinged > 10) {
      selfAs(Stoppable.class).stop();
    } else {
      self.ping();
    }
  }
  

  @Override
  public void stop() {
    System.out.println("X Hey!");
    
    cancellable.cancel();
    super.stop();
  }





  // DON'T USE FOR ANYTHING BUT STATE OR YOU WILL
  // FALL OFF THE CLIFF IN MONTY PYTHON'S HOLY GRAIL
  public TestState viewTestState() {
    TestState state = new TestState();
    state.putValue("ping", this.pinged);
    return state;
  }
}
