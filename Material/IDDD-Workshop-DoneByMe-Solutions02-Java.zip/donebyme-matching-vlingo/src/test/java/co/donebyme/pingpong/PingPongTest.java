package co.donebyme.pingpong;

import org.junit.After;
import org.junit.Before;

import io.vlingo.actors.World;
import io.vlingo.actors.testkit.TestWorld;

public class PingPongTest {
  private TestWorld testWorld;
  private World world;

//  @Test
//  public void shouldPingOnce() throws Exception {
//    TestActor<Ponger> ponger = testWorld.actorFor(Ponger.class, PongerActor.class);
//    TestActor<Pinger> pinger = testWorld.actorFor(Pinger.class, PingerActor.class, ponger.actor());
//    pinger.actor().ping();
//    
//    Thread.sleep(1000);
//  }

//  @Test
//  public void testShouldPingOnce() {
//    TestActor<Pinger> pinger = testWorld.actorFor(Pinger.class, PingerActor.class);
//    TestStateView view = pinger.actorInside();
//    pinger.actor().ping();
//    assertEquals(1, (int) view.viewTestState().valueOf("ping"));
//  }

  @Before
  public void setUp() {
    testWorld = TestWorld.startWithDefaults("ping-pong");
    //world = World.startWithDefaults("ping-pong");
  }
  
  @After
  public void tearDone() {
    //world.terminate();
    testWorld.terminate();
  }
}
