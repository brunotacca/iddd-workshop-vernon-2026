package co.donebyme.matching.infra.messaging;

import co.donebyme.matching.infra.API;
import co.donebyme.matching.infra.persistence.MatchingJournal;
import co.donebyme.matching.model.Id;
import co.donebyme.matching.model.proposal.PricingVerified;
import co.donebyme.matching.model.proposal.Proposal;
import co.donebyme.pricing.command.AnalyzePricing;
import co.vaughnvernon.mockroservices.journal.Journal;
import co.vaughnvernon.mockroservices.messagebus.Message;
import co.vaughnvernon.mockroservices.messagebus.MessageBus;
import co.vaughnvernon.mockroservices.messagebus.Subscriber;
import co.vaughnvernon.mockroservices.messagebus.Topic;
import co.vaughnvernon.mockroservices.model.Command;
import co.vaughnvernon.mockroservices.model.SourcedEntity;

public class ProposalProcess extends SourcedEntity<Command> implements Subscriber {

  private Journal journal = MatchingJournal.journal;
  
  public static void start() {
    final ProposalProcess process = new ProposalProcess();
    final MessageBus messageBus = MessageBus.start("donebyme");
    final Topic allTopic = messageBus.openTopic("all");
    allTopic.subscribe(process);
  }
  
  @Override
  public void handle(Message message) {
    switch (message.type) {
    case "donebyme.matching.ProposalSubmitted":
      append(new AnalyzePricing(...));
      break;
    case "donebyme.pricing.PricingVerified":
      API.proposal().verifyPricing(pricingVerified.originatorId);
      break;
    case "donebyme.pricing.PricingRejected":
      API.proposal().denyPricing(pricingDenied.originatorId, pricingDenied.suggestedPrice);
      break;
    case "donebyme.matching.PricingVerified":
      Step step = API.proposal().nextProcessStepFor(...);
      append(commandFor(step));
      break;
    case "donebyme.profile.DoersRecommended":
      API.proposal().registerRecommededDoers(doersRecommended.taskId, doersRecommended.doers);
      break;
    case "donebyme.matching.RecommendedDoersRegistered":
      append(new LocateAvailabilty(...));
      break;
    case "donebyme.scheduling.AvailabiltyLocated":
      API.proposal().mergeAvailableDoers(availability.taskId, doers);
      break;
    case "donebyme.matching.AvailableDoersMerged":
      append(new NotifyAvailableDoers(...));
      break;
    }
  }
  
  private void append(Command command) {
    journal.write(command.correlationId, command);
  }
  
  private Command commandFor(Step step) {
    return new RecommendDoers(...);
  }
}
