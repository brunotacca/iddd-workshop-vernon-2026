package co.donebyme.pricing.command;

import java.util.Date;

import co.vaughnvernon.mockroservices.model.Command;

public class AnalyzePricing extends Command {
  public final String pricedItemId;
  public final String[] taxonomy;
  public final Date dueDate;
  public final long price;
  
  public AnalyzePricing(final String pricedItemId, final String[] taxonomy, final Date dueDate, final long price) {
    this.pricedItemId = pricedItemId;
    this.taxonomy = taxonomy;
    this.dueDate = dueDate;
    this.price = price;
  }
}
