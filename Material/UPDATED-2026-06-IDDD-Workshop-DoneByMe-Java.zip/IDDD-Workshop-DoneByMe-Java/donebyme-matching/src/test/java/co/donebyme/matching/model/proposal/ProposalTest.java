package co.donebyme.matching.model.proposal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Collections;
import java.util.Date;

import org.junit.Test;

import co.donebyme.matching.model.Client;
import co.donebyme.matching.model.Description;
import co.donebyme.matching.model.Doer;
import co.donebyme.matching.model.Keywords;
import co.donebyme.matching.model.Summary;

public class ProposalTest {

  // Domain Expert Readable
  @Test
  public void testThatProposalSubmits() {
      // GIVEN:
      Client client = client();
      Expectations expectations = expectations();
  
      // WHEN:
      Proposal proposal = Proposal.submitFor(client, expectations);
      
      // THEN:
      assertNotNull(proposal);
      assertEquals(1, proposal.applied().size());
      assertEquals(ProposalSubmitted.class, proposal.applied().get(0).getClass());
  }

  @Test
  public void testThatProposalMatchesWithDoer() {
    // GIVEN:
    Proposal proposal = Proposal.submitFor(client(), expectations());
    proposal.verifyPricing();
    proposal.verifyScheduling();
    assertTrue(proposal.isAcceptable());
    proposal.applied().clear();
    
    // WHEN:
    //proposal.matchWith(doer());
    
    // THEN:
    assertEquals(1, proposal.applied().size());
    //assertEquals(ProposalMatched.class, proposal.applied().get(0).getClass());
    assertEquals(client(), proposal.client());
    // assertEquals(doer(), proposal.doer());
    assertTrue(proposal.progress().wasMatched());
  }

  private Client client() {
    return Client.from("12345");
  }

  private Doer doer() {
    return Doer.preferredFrom("ABC");
  }
  
  private Expectations expectations() {
    return
        Expectations.ofSubmitted(
            Summary.has("I need my windows washed by the best."),
            Description.has("When I say 'jump,' you ask 'how high?'"),
            Keywords.are("#windows", "#washing", "#indoor", "#outdoor", "#extra-tall"),
            new Date(System.currentTimeMillis() + (24 * 60 * 60 * 1000)),
            Collections.singleton(Step.ordered(1, Description.has("Step 1"))),
            1995);
  }
}
