package co.donebyme.matching.model.proposal;

import java.util.Date;

enum Spec {
  PricingDenied,
  PricingVerified,
  SchedulingDenied,
  SchedulingVerified,
  Submitted,
  Resubmitted,
  PricingPreviouslyDenied,
  PricingPreviouslyVerified,
  Matched;

  private Date lastAdvanced;

  public boolean sameAs(Object other) {
	if (other == null || other.getClass() != Spec.class || this != other) {
		return false;
	}

	return lastAdvanced.equals(((Spec)other).lastAdvanced);
  }
}
