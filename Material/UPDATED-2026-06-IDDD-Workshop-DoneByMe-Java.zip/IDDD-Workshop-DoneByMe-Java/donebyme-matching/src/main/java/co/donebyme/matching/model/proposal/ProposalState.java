package co.donebyme.matching.model.proposal;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import co.donebyme.matching.model.Client;
import co.donebyme.matching.model.Doer;
import co.donebyme.matching.model.Id;

public final class ProposalState {
	public final Id id;
	public final Client client;
	public final Expectations expectations;
	public final Progress progress;
	public final Doer matchedDoer;
	public final List<Doer> backupDoers;

	public static ProposalState with(Id id, Client client, Expectations expectations, Progress progress) {
		return new ProposalState(id, client, expectations, progress);
	}

	public ProposalState withResubmitted(Expectations expectations) {
		return new ProposalState(id, client, expectations, progress);
	}

	public ProposalState withAdvanced(Progress progress) {
		return new ProposalState(id, client, expectations, progress, matchedDoer, backupDoers);
	}

	public ProposalState withMatched(Doer doer) {
		return new ProposalState(id, client, expectations, progress, doer, backupDoers);
	}

	public ProposalState withBackup(Doer doer) {
		List<Doer> backupDoers = new ArrayList<>(this.backupDoers);
		backupDoers.add(doer);
		return new ProposalState(id, client, expectations, progress, this.matchedDoer,
				Collections.unmodifiableList(backupDoers));
	}

	private ProposalState(Id id, Client client, Expectations expectations, Progress progress) {
		this.id = id;
		this.client = client;
		this.expectations = expectations;
		this.progress = progress;
		this.matchedDoer = null;
		this.backupDoers = Collections.unmodifiableList(new ArrayList<>(0));
	}

	private ProposalState(Id id, Client client, Expectations expectations, Progress progress, Doer matchedDoer, List<Doer> backupDoers) {
		this.id = id;
		this.client = client;
		this.expectations = expectations;
		this.progress = progress;
		this.matchedDoer = matchedDoer;
		this.backupDoers = backupDoers;
	}
}
