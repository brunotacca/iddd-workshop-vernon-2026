package co.donebyme.matching.model.proposal;

import co.donebyme.matching.model.Client;
import co.donebyme.matching.model.Doer;
import co.donebyme.matching.model.Id;
import co.vaughnvernon.mockroservices.model.DomainEvent;

public final class ProposalAccepted extends DomainEvent {
	public final Id id;
	public final Client client;
	public final Doer doer;

	public ProposalAccepted(Id id, Client client, Doer doer) {
		this.id = id;
		this.client = client;
		this.doer = doer;
	}
}
